/*****************************************************************************
 *                   Copyright (C) 2009-2013 Synopsys, Inc.                  *
 *       This software and the associated documentation are confidential     *
 *                  and proprietary to Synopsys, Inc.                        *
 *        Your use or disclosure of this software is subject                 *
 *      to the terms and conditions of a written license agreement           *
 *           between you, or your company, and Synopsys, Inc.                *
 *                                                                           *
 *****************************************************************************/
#include "sc_stop_control.h"
#include <systemc>
#include <set>
#include <iostream>
#include <stdlib.h>

namespace scml2_sc_stop_control {
  typedef std::set<void*> tControllers;
  tControllers gControllers;
}

void scml2::register_sc_stop_controller(void* handle) {
  using namespace scml2_sc_stop_control;
  std::pair<tControllers::iterator, bool> result = gControllers.insert(handle);
  if (!result.second) {
    std::cerr << "Error in register_sc_stop_controller(): the supplied handle 0x" << handle << " has already been registered before!" << std::endl;
    abort();
  }
}

bool scml2::deregister_sc_stop_controller(void* handle) {
  using namespace scml2_sc_stop_control;
  std::size_t num_erased = gControllers.erase(handle);
  if (num_erased == 0) {
    std::cerr << "Error in deregister_sc_stop_controller(): the supplied handle 0x" << handle << " has not been registered before!" << std::endl;
    abort();
  }
  if (!gControllers.empty()) {
    return false;
  }
  if (sc_core::sc_get_simulator_status()==sc_core::SC_SIM_OK) {
    sc_core::sc_stop();
  }
  return true;
}

int scml2::get_num_registered_sc_stop_controllers() {
  using namespace scml2_sc_stop_control;
  return (int)gControllers.size();
}

void scml2::collect_registered_sc_stop_controllers(std::vector<void*>& result) {
  using namespace scml2_sc_stop_control;
  for (tControllers::const_iterator i=gControllers.begin(); i!=gControllers.end(); ++i) {
    result.push_back(*i);
  }
}
