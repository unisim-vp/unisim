/*****************************************************************************
 *                   Copyright (C) 2015 Synopsys, Inc.                       *
 *       This software and the associated documentation are confidential     *
 *                  and proprietary to Synopsys, Inc.                        *
 *        Your use or disclosure of this software is subject                 *
 *      to the terms and conditions of a written license agreement           *
 *           between you, or your company, and Synopsys, Inc.                *
 *                                                                           *
 *****************************************************************************/
#ifndef __INITIATOR_PORT_ADAPTOR_IMPL_H__
#define __INITIATOR_PORT_ADAPTOR_IMPL_H__ 

#include <scml2/port_adaptor_impl.h>
#include <scml2/initiator_port_adaptor.h>

namespace scml2
{

class initiator_port_adaptor_impl : public port_adaptor_impl,
                                    public initiator_port_adaptor,
                                    scml_clock_parameter_change_control_if::client {
public:
  initiator_port_adaptor_impl(const std::string& name, socket_if* sock);
  ~initiator_port_adaptor_impl();

  /** Port Adaptor interface */
  virtual std::string get_name() const { return name(); }
  virtual unsigned int get_bus_width() const { return mSocket->get_bus_width(); }
  virtual unsigned int get_burst_length(tlm::tlm_generic_payload& trans) const { return port_adaptor_impl::get_burst_length(trans); }

  /** Set attributes */
  virtual void set_attribute(const std::string& name, int value) { port_adaptor_impl::set_attribute(name, value); }
  virtual int get_attribute(const std::string& name) { return port_adaptor_impl::get_attribute(name); }

  /** Clock interface */
  ///@{
  virtual void operator()(scml_clock_if* clk);
  virtual sc_time clock_cycles_to_time(unsigned int cycles) const { return port_adaptor_impl::clock_cycles_to_time(cycles); }
  virtual void set_clock_changed_callback(port_adaptor::clock_changed_callback_base* cbk) { return port_adaptor_impl::set_clock_changed_callback(cbk); }
  ///@}

  virtual scml2::callback_event_enum get_event_id(unsigned int protocol_state) const { return port_adaptor_impl::get_event_id(protocol_state); }

  /** API to register a callback for the specified event in the transaction life cycle */
  virtual bool set_timing_callback(callback_event_enum event_id, timing_callback_base* cb) { return port_adaptor_impl::set_timing_callback(event_id, cb); }

  /** Convenience function to return if there is any callback registered for a particular protocol state */
  virtual bool has_callback(unsigned int protocol_state) const { return port_adaptor_impl::has_callback(protocol_state); }

  /** API to request a transaction object */
  virtual tlm::tlm_generic_payload& alloc_and_init_trans(tlm::tlm_command cmd);

  /** API to send a transaction over the bus */
  using initiator_port_adaptor::send_transaction;
  virtual bool send_transaction(tlm::tlm_generic_payload& payload);

  /** mappable_if */
  virtual std::string get_mapped_name() const;

  virtual void b_transport(tlm::tlm_generic_payload& trans, sc_core::sc_time& t);
  virtual bool get_direct_mem_ptr(tlm::tlm_generic_payload& trans, tlm::tlm_dmi& dmiData);
  virtual unsigned int transport_dbg(tlm::tlm_generic_payload& trans);

  virtual void register_bw_direct_mem_if(tlm::tlm_bw_direct_mem_if* bwInterface);
  virtual void unregister_bw_direct_mem_if(tlm::tlm_bw_direct_mem_if* bwInterface);

  /** bw transport interface */
  virtual void invalidate_direct_mem_ptr(sc_dt::uint64 start, sc_dt::uint64 end);

protected:
  void handle_clock_parameter_change_request(scml_clock_parameter_change_control_if* clk_control_if);
  void signal_ready_for_clock_change();
  void handle_clock_parameters_updated(scml_clock_if* clk);
  void on_txn_complete(tlm::tlm_generic_payload& trans, const sc_time& t);

protected:
  scml_clock_parameter_change_control_if* m_clk_control_if;
  bool m_clk_period_change_pending;
  sc_event m_clk_change_event;

  socket_if* mSocket;

  // attributes
  unsigned int m_read_capacity;
  unsigned int m_write_capacity;
  unsigned int m_rd_data_accept_cycles;
  unsigned int m_wr_data_trigger_cycles;
  unsigned int m_wr_rsp_accept_cycles;

  std::set<tlm::tlm_bw_direct_mem_if*> mBwDirectMemIfs;
  scml2::mem_manager<scml2::ft_generic_payload> m_pool;
};

} // namespace scml2

#endif  //__INITIATOR_PORT_ADAPTOR_IMPL_H__
