/*****************************************************************************
 *                   Copyright (C) 2013 Synopsys, Inc.                       *
 *       This software and the associated documentation are confidential     *
 *                  and proprietary to Synopsys, Inc.                        *
 *        Your use or disclosure of this software is subject                 *
 *      to the terms and conditions of a written license agreement           *
 *           between you, or your company, and Synopsys, Inc.                *
 *                                                                           *
 *****************************************************************************/

#include <algorithm>
#include <iomanip>
#include <scml2/port_adaptor_impl.h>

namespace scml2
{
std::ostream* port_adaptor_impl::trace_stream = 0;

port_adaptor_impl::port_adaptor_impl(const std::string& name)
 : m_clk(NULL)
 , m_clk_period(SC_ZERO_TIME)
 , m_clk_changed_callback(NULL)
{
  // initialise tracing stream on first entry
  // environment variable can specify path to trace file, or default to std::cout
  if (!trace_stream) {
    const char* trace_filename = getenv("PORT_ADAPTOR_TRACE_FILENAME");
    if (trace_filename) {
      std::ofstream* trace_ofstream = new std::ofstream(trace_filename);
      if (trace_ofstream->good()) {
        trace_stream = trace_ofstream;
      }
      else {
        delete trace_ofstream;
      }
    }

    if (!trace_stream) {
      trace_stream = &std::cout;
    }
  }

  // enable tracing for this adaptor if matching environment variable set
  const char* env_value = getenv("SNPS_PORT_ADAPTOR_TRACE_ALL");
  if (env_value && strcmp(env_value, "true") == 0) {
    m_trace_enabled = true;
  }
  else {
    std::string env_name(name);
    std::replace(env_name.begin(), env_name.end(), '.', '_');

    env_value = getenv(env_name.c_str());
    m_trace_enabled = (env_value && strcmp(env_value, "true") == 0);
  }

  for (int i = 0; i < MAX_CBK_EVENT_ID_E; i++)
    m_eventId2ProtoState[i] = 0;
}

port_adaptor_impl::~port_adaptor_impl()
{
  if (m_clk) {
    m_clk->unregister_observer(this);
  }
  delete m_clk_changed_callback;
}

std::string
port_adaptor_impl::event_name(callback_event_enum event_id) const
{
  switch (event_id) {
    case CBK_EVENT_NONE:      return "EVENT_NONE";
    case WR_ADDR_START:       return "WR_ADDR_START";
    case WR_ADDR_END:         return "WR_ADDR_END";
    case WR_DATA_START:       return "WR_DATA_START";
    case WR_DATA_END:         return "WR_DATA_END";
    case WR_DATA_LAST_START:  return "WR_DATA_LAST_START";
    case WR_DATA_LAST_END:    return "WR_DATA_LAST_END";
    case WR_RSP_START:        return "WR_RSP_START";
    case WR_RSP_END:          return "WR_RSP_END";
    case RD_ADDR_START:       return "RD_ADDR_START";
    case RD_ADDR_END:         return "RD_ADDR_END";
    case RD_DATA_START:       return "RD_DATA_START";
    case RD_DATA_END:         return "RD_DATA_END";
    case RD_DATA_LAST_START:  return "RD_DATA_LAST_START";
    case RD_DATA_LAST_END:    return "RD_DATA_LAST_END";
    default:
    {
      std::ostringstream os;
      os << "Unknown(" << event_id << ")";
      return os.str();
    }
  }
}

std::string
port_adaptor_impl::state_name(unsigned int protocol_state) const
{
  std::ostringstream os;
  os << "Unknown(" << protocol_state << ")";
  return os.str();
}

void
port_adaptor_impl::operator()(scml_clock_if* clk)
{
  assert(clk != NULL);      // cannot bind a NULL clock
  assert(m_clk == NULL);    // only bind clock once

  m_clk = clk;
  m_clk_period = m_clk->get_period();

  // register observer to be notified of clock period changes
  m_clk->register_observer(this);
}

sc_time
port_adaptor_impl::clock_cycles_to_time(unsigned int cycles) const
{
  if (m_clk) {
    return m_clk_period * cycles;
  }
  else {
    PORT_ADAPTOR_ERROR("Cannot convert clock cycles. No clock interface has been bound.");
    return sc_core::SC_ZERO_TIME;
  }
}

void
port_adaptor_impl::set_clock_changed_callback(port_adaptor::clock_changed_callback_base* cbk)
{
  delete m_clk_changed_callback;
  m_clk_changed_callback = cbk;
}

void
port_adaptor_impl::handle_clock_parameters_updated(scml_clock_if* clk)
{
  assert(m_clk == clk);

  m_clk_period = m_clk->get_period();
  if (m_clk_changed_callback)
    m_clk_changed_callback->notify(clk);  // invoke user model callback
}

void
port_adaptor_impl::handle_clock_deleted(scml_clock_if* clk)
{
  assert(m_clk == clk);
  (void)clk;                            // prevent unused variable warning

  m_clk->unregister_observer(this);
  m_clk = 0;
  m_clk_period = SC_ZERO_TIME;

  // TODO:invoke m_clk_changed_callback?
}

void
port_adaptor_impl::set_attribute(const std::string& name, int value)
{
  std::map<std::string, int*>::iterator itr = m_attributes.find(name);
  if (itr == m_attributes.end() || (itr->second == NULL)) {
    PORT_ADAPTOR_ERROR("set_attribute : unknown attribute name " << name);
  }
  else {
    *(itr->second) = value;
  }
}

int
port_adaptor_impl::get_attribute(const std::string& name)
{
  std::map<std::string, int*>::const_iterator itr = m_attributes.find(name);
  if (itr == m_attributes.end() || (itr->second == NULL)) {
    PORT_ADAPTOR_ERROR("get_attribute : unknown attribute name " << name);
    return 0;
  }
  else {
    return *(itr->second);
  }
}

bool
port_adaptor_impl::set_timing_callback(callback_event_enum event_id, timing_callback_base* cb)
{
  assert((unsigned int)event_id < MAX_CBK_EVENT_ID_E);

  if ((event_id == CBK_EVENT_NONE) || ((unsigned int)event_id >= MAX_CBK_EVENT_ID_E)) {
    PORT_ADAPTOR_ERROR("Cannot set timing callback: invalid event: " << event_name(event_id));
    return false;
  }

  unsigned int proto_state = m_eventId2ProtoState[event_id];

  if (proto_state == 0)  {
    PORT_ADAPTOR_ERROR("Cannot set timing callback: no protocol state maps to event " << event_name(event_id) << " for this port adaptor");
    return false;
  }

  m_callbacks[proto_state] = cb;
  return true;
}

scml2::callback_event_enum
port_adaptor_impl::get_event_id(unsigned int protocol_state) const
{
  for (int i = WR_ADDR_START; i < MAX_CBK_EVENT_ID_E; ++i) {
    if (m_eventId2ProtoState[i] == protocol_state) {
      return (scml2::callback_event_enum)i;
    }
  }
  return MAX_CBK_EVENT_ID_E;
}

bool
port_adaptor_impl::has_callback(unsigned int protocol_state) const
{
  callback_map::const_iterator cb = m_callbacks.find(protocol_state);
  return ((cb != m_callbacks.end()) && (cb->second != NULL));
}

void
port_adaptor_impl::invoke_fwd_timing_callback( unsigned int protocol_state,
                                         tlm::tlm_generic_payload& trans,
                                         sc_core::sc_time& t)
{
  // invoke timing callback for forwarded phases; user cannot change protocol
  // state but may want to log something or adjust timing
  tlm::tlm_sync_enum return_status = invoke_timing_callback(protocol_state, trans, t);
  if (return_status != tlm::TLM_UPDATED) {
    PORT_ADAPTOR_ERROR("callback for state " << state_name(protocol_state) << " did not return tlm::TLM_UPDATED");
    assert(false);
  }
}

tlm::tlm_sync_enum
port_adaptor_impl::invoke_timing_callback( unsigned int protocol_state,
                                      tlm::tlm_generic_payload& trans,
                                      sc_core::sc_time& t)
{
  callback_map::iterator cb = m_callbacks.find(protocol_state);
  if ((cb == m_callbacks.end()) || (cb->second == NULL)) {
    PORT_ADAPTOR_TRACE((&trans), t, state_name(protocol_state) << " : default callback");
    return tlm::TLM_UPDATED;
  }
  else {
    PORT_ADAPTOR_TRACE((&trans), t, state_name(protocol_state));
    return cb->second->execute(trans, t);
  }
}

unsigned int
port_adaptor_impl::get_burst_size(tlm::tlm_generic_payload& trans) const
{
  GET_EXT_ATTR((&trans), scml2::burst_size_extension, unsigned int, burst_size);
  return (burst_size == 0) ? (get_bus_width() / 8) : burst_size;   // burst size not specified; default to bus width
}

unsigned int
port_adaptor_impl::get_burst_length(tlm::tlm_generic_payload& trans) const
{
  unsigned int burst_size = get_burst_size(trans);
  unsigned int burst_len = (trans.get_data_length() + burst_size - 1) / burst_size;

/*
  // TODO: AXI, GFT: if address is unaligned, there will be an extra beat
  if (m_protocol == "AXI" || m_protocol == "GFT") {
    if ((trans.get_address() % burst_size) != 0)
      burst_len++;
  }
*/
  return burst_len;
}

void
port_adaptor_impl::setup_data_beat_avail_array(tlm::tlm_generic_payload& trans, unsigned int beat_count, unsigned int trigger_cycles)
{
  GET_EXT_ATTR((&trans), scml2::can_accept_data_beat_array_extension, bool, support_beat_array);
  if (support_beat_array) {
    SET_ARRAY_EXT_ATTR((&trans), scml2::data_beat_avail_extension, unsigned int, avail_cycles, beat_count);
    for (unsigned int i = 0; i < beat_count; ++i) {
      avail_cycles[i] = i * trigger_cycles;
    }

    if (m_trace_enabled) {
      std::ostringstream stream;
      for (unsigned int i = 0; i < beat_count; ++i) {
        stream << " " << avail_cycles[i];
      }
      sc_time dummy_time(SC_ZERO_TIME);
      PORT_ADAPTOR_TRACE((&trans), dummy_time, "data beat avail array:" << stream.str()); 
    }
  }
}

sc_time
port_adaptor_impl::setup_data_beat_used_array(tlm::tlm_generic_payload& trans, unsigned int accept_cycles)
{
  sc_time last_used_time(SC_ZERO_TIME);

  GET_ARRAY_EXT_ATTR((&trans), scml2::data_beat_avail_extension, unsigned int, avail_cycles, avail_count);
  if (avail_count > 0) {
    SET_ARRAY_EXT_ATTR((&trans), scml2::data_beat_used_extension, unsigned int, used_cycles, avail_count);
    used_cycles[0] = avail_cycles[0];
    for (unsigned int i = 1; i < avail_count; ++i) {
      //beat time = last beat time + difference between the time of corresponding avail time beat 
      //            + rd data delay
      used_cycles[i] = used_cycles[i-1] + (avail_cycles[i] - avail_cycles[i-1]) + accept_cycles;
    }
    last_used_time += m_clk_period * used_cycles[avail_count-1];

    if (m_trace_enabled) {
      std::ostringstream stream;
      for (unsigned int i = 0; i < avail_count; ++i) {
        stream << " " << used_cycles[i];
      }
      sc_time dummy_time(SC_ZERO_TIME);
      PORT_ADAPTOR_TRACE((&trans), dummy_time, "data beat used array:" << stream.str()); 
    }
  }

  return last_used_time;
}

void
port_adaptor_impl::reset_beat_array_extensions(tlm::tlm_generic_payload& trans)
{
  // reset extensions
  scml2::can_accept_data_beat_array_extension* support_beat_array_ext = NULL;
  trans.get_extension(support_beat_array_ext);
  if (support_beat_array_ext) {
    support_beat_array_ext->attr_val = false;
    GET_ARRAY_EXT_ATTR((&trans), scml2::data_beat_avail_extension, unsigned int, data_beat_avail, avail_count);
    if (avail_count > 0) {
      SET_ARRAY_EXT_ATTR((&trans), scml2::data_beat_used_extension,  unsigned int, dummy, 0);
      SET_ARRAY_EXT_ATTR((&trans), scml2::data_beat_avail_extension, unsigned int, dummy1, 0);
      (void)(dummy);    // unused
      (void)(dummy1);   // unused
    }
  }
}

std::string
port_adaptor_impl::byte_array_to_str(unsigned char* p_data, unsigned int length) const
{
  std::ostringstream os;
  for (unsigned int i = 0; i < length; ++i) {
    os << " " << setw(2) << setfill('0') << hex << (int)(p_data[i]);
  }
  return os.str();
}

} // namespace scml2
