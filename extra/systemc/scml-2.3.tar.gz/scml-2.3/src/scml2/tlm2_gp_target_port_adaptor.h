/*****************************************************************************
 *                   Copyright (C) 2014 Synopsys, Inc.                       *
 *       This software and the associated documentation are confidential     *
 *                  and proprietary to Synopsys, Inc.                        *
 *        Your use or disclosure of this software is subject                 *
 *      to the terms and conditions of a written license agreement           *
 *           between you, or your company, and Synopsys, Inc.                *
 *                                                                           *
 *****************************************************************************/
#ifndef __TLM2_GP_TARGET_PORT_ADAPTOR_H__
#define __TLM2_GP_TARGET_PORT_ADAPTOR_H__

#include <tlm.h>
#include <scml2/target_port_adaptor_impl.h>

namespace scml2
{

class tlm2_gp_target_port_adaptor : public target_port_adaptor_impl
{
public:
  tlm2_gp_target_port_adaptor(const std::string& name, target_port_adaptor::socket_if* sock);

  /* Port adaptor protocol details */
  virtual std::string get_protocol() const { return "TLM2_GP"; }
  virtual bool has_data_phase() const { return false; }
  virtual bool has_wr_rsp() const { return true; }

  /* FT initiator state machine interface */
  virtual bool update_transaction(tlm::tlm_generic_payload& trans, sc_time& t);
  virtual bool update_transaction(tlm::tlm_generic_payload& trans, sc_time& t, scml2::callback_event_enum event_id);
  virtual tlm::tlm_sync_enum nb_transport_fw(tlm::tlm_generic_payload& trans, tlm::tlm_phase& phase, sc_time& t);

protected:
  virtual bool is_behavior_event(scml2::callback_event_enum event_id) const;
  virtual std::string state_name(unsigned int protocol_state) const;

private:
  tlm::tlm_phase_enum event_id_to_phase(scml2::callback_event_enum event_id);
  scml2::callback_event_enum phase_to_event_id(tlm::tlm_generic_payload& trans, const tlm::tlm_phase& phase);
  void begin_response(tlm::tlm_generic_payload& trans, sc_time& t);
  tlm::tlm_sync_enum process_bw_states(tlm::tlm_generic_payload& trans, tlm::tlm_phase& phase, sc_time& t);
  tlm::tlm_sync_enum process_fw_states(tlm::tlm_generic_payload& trans, tlm::tlm_phase& phase, sc_time& t);
  tlm::tlm_sync_enum advance_state(tlm::tlm_generic_payload& trans, sc_time& t);

private:
  struct payload_info
  {
    scml2::callback_event_enum state;
    payload_info() : state(scml2::MAX_CBK_EVENT_ID_E) { }
  };

  scml2::ft_channel<tlm2_gp_target_port_adaptor> m_response_channel;
  std::map<tlm::tlm_generic_payload*, payload_info> m_payloads;
  bool m_inside_nb_transport_fw;
  bool m_pending_bw_state;
  sc_time m_pending_bw_state_time;
};

} // namespace scml2

#endif  // __TLM2_GP_TARGET_PORT_ADAPTOR_H__
