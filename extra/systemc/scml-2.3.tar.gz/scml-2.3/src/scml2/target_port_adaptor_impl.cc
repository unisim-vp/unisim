/*****************************************************************************
 *                   Copyright (C) 2013 Synopsys, Inc.                       *
 *       This software and the associated documentation are confidential     *
 *                  and proprietary to Synopsys, Inc.                        *
 *        Your use or disclosure of this software is subject                 *
 *      to the terms and conditions of a written license agreement           *
 *           between you, or your company, and Synopsys, Inc.                *
 *                                                                           *
 *****************************************************************************/

#include <scml2/target_port_adaptor_impl.h>
#include <scml2/memory_base.h>
#include <scml2/memory_region_registry.h>
#include <scml2/thread_pool.h>
#include <sysc/kernel/sc_dynamic_processes.h>
#include <scml2/axi_ft_target_port_adaptor.h>
#include <scml2/axi4_stream_target_port_adaptor.h>
#include <scml2/gft_target_port_adaptor.h>
#include <scml2/tlm2_gp_target_port_adaptor.h>

typedef std::map<scml2::mappable_if*, scml2::target_port_adaptor_impl*> memory_adaptor_map;
static memory_adaptor_map adaptor_map;

namespace scml2
{


//-----------------------------------------------------------------------------

target_port_adaptor*
target_port_adaptor::_create_adaptor(const std::string& protocol, const std::string& name, socket_if* sock)
{
  if (protocol == "TLM2_GP") {
    return new tlm2_gp_target_port_adaptor(name, sock);
  }
  else if (protocol == "AXI") {
    return new axi_ft_target_port_adaptor(name, sock);
  }
  else if (protocol == "AXI4Stream") {
    return new axi4_stream_target_port_adaptor(name, sock);
  }
  else if (protocol == "GFT") {
    return new gft_target_port_adaptor(name, sock);
  }
  else {
    cerr << "Failed to create target_port_adaptor : no adaptor available for protocol " << protocol << endl;
    //sc_exit();
    return NULL;
  }
}

bool
target_port_adaptor::set_target_callback(mappable_if& dest, callback_event_enum event_id, timing_callback_base* cb)
{
  memory_adaptor_map::iterator itr = adaptor_map.find(&dest);
  if (itr == adaptor_map.end()) {
    cout << "set_target_callback failed: mappable_if object not bound to a target_port_adaptor_impl" << endl;
    return false;
  }
  else {
    return itr->second->port_adaptor_impl::set_timing_callback(event_id, cb);
  }
}

//-----------------------------------------------------------------------------

target_port_adaptor_impl::target_port_adaptor_impl(const std::string& name, socket_if* sock)
  : port_adaptor_impl(name),
    target_port_adaptor(name),
    mSocket(sock),
    mDestination(0),
    mBoundDestinations(0),
    mSelectCallback(0),
    mError(name, logging::severity::error()),
    // attribute default values
    m_read_capacity(1),
    m_write_capacity(1),
    m_rd_cmd_accept_cycles(0),
    m_rd_data_trigger_cycles(0),
    m_wr_cmd_accept_cycles(0),
    m_wr_data_accept_cycles(0),
    m_wr_rsp_trigger_cycles(0)
{
  // link attributes
  m_attributes["read_capacity"] = (int*)&m_read_capacity;
  m_attributes["write_capacity"] = (int*)&m_write_capacity;
  m_attributes["rd_cmd_accept_cycles"] = (int*)&m_rd_cmd_accept_cycles;
  m_attributes["rd_data_trigger_cycles"] = (int*)&m_rd_data_trigger_cycles;
  m_attributes["wr_cmd_accept_cycles"] = (int*)&m_wr_cmd_accept_cycles;
  m_attributes["wr_data_accept_cycles"] = (int*)&m_wr_data_accept_cycles;
  m_attributes["wr_rsp_trigger_cycles"] = (int*)&m_wr_rsp_trigger_cycles;
}

target_port_adaptor_impl::~target_port_adaptor_impl()
{
  delete mSocket;

  // remove any memories bound to this adaptor
  memory_adaptor_map::iterator itr = adaptor_map.begin();
  while (itr != adaptor_map.end()) {
    memory_adaptor_map::iterator check = itr++;
    if (check->second == this)
      adaptor_map.erase(check);
  }

  if (mSelectCallback) {
    mSelectCallback->unref();
  }
}

void
target_port_adaptor_impl::operator()(mappable_if& destination)
{
  if (!mDestination) {
    // The first bound destination is the default destination
    mDestination = &destination;
  }
  mDestination->register_bw_direct_mem_if(this);
  mBoundDestinations++;

  adaptor_map[&destination] = this;
}

bool
target_port_adaptor_impl::is_behavior_event(scml2::callback_event_enum event_id) const
{
  return event_id == RD_ADDR_START || event_id == WR_DATA_LAST_START;
}

void
target_port_adaptor_impl::
set_select_callback(memory_select_callback_base* cb)
{
  if (mSelectCallback) {
    mSelectCallback->unref();
  }
  mSelectCallback = cb;
  mSelectCallback->ref();
}

mappable_if*
target_port_adaptor_impl::get_destination(tlm::tlm_generic_payload& payload, bool error_if_not_bound) const
{
  if (mSelectCallback) {
    return mSelectCallback->execute(payload);
  }
  else {
    if (mDestination) {
      if (mBoundDestinations != 1) {
        SCML2_LOG(mError) << "Multiple interfaces bound, and no select callback registered" << std::endl;
      }
    }
    else if (error_if_not_bound) {
      SCML2_LOG(mError) << "no interface bound" << std::endl;
    }
    return mDestination;
  }
}

void
target_port_adaptor_impl::b_transport(tlm::tlm_generic_payload& trans, sc_time& t)
{
  mappable_if* destination = get_destination(trans, true);
  if (destination) {
    destination->b_transport(trans, t);
  }
}

unsigned int
target_port_adaptor_impl::transport_dbg(tlm::tlm_generic_payload& trans) 
{
  mappable_if* destination = get_destination(trans, true);
  if (destination) {
    return destination->transport_dbg(trans);
  }
  else {
    return 0;
  }
}

bool
target_port_adaptor_impl::get_direct_mem_ptr(tlm::tlm_generic_payload& trans, tlm::tlm_dmi& dmi_data) 
{
  mappable_if* destination = get_destination(trans, false);
  if (destination) {
    return destination->get_direct_mem_ptr(trans, dmi_data);
  }
  else {
    dmi_data.set_start_address(0);
    dmi_data.set_end_address(~0ULL);
    return false;
  }
}

void
target_port_adaptor_impl::invalidate_direct_mem_ptr(unsigned long long startRange, unsigned long long endRange)
{
  mSocket->invalidate_direct_mem_ptr(startRange, endRange);
}

tlm::tlm_sync_enum
target_port_adaptor_impl::do_invoke_callback(scml2::callback_event_enum event_id, tlm::tlm_generic_payload& trans, sc_time& t)
{
  // Invoke the bound object's b_transport callback, performing nb2b if necessary

  mappable_if* destination = get_destination(trans, false);
  if (destination) {
    bool sync_required = true;
    memory_base* base = dynamic_cast<memory_base*>(
      memory_region_registry::get_instance().find_memory_region_by_name(destination->get_mapped_name())
    );
    // if the memory and all aliases are NEVER_SYNCING we don't need to sync
    if (base) {
      if (trans.is_read() && base->has_never_syncing_read_behavior()) {
        sync_required = false;
        for (memory_base::AliasesIterator itr = base->begin_alias(); itr != base->end_alias(); ++itr) {
          if (!(*itr)->has_never_syncing_read_behavior()) {
            sync_required = true;
            break;
          }
        }
      }
      else if (!trans.is_read() && base->has_never_syncing_write_behavior()) {
        sync_required = false;
        for (memory_base::AliasesIterator itr = base->begin_alias(); itr != base->end_alias(); ++itr) {
          if (!(*itr)->has_never_syncing_write_behavior()) {
            sync_required = true;
            break;
          }
        }
      }
    }
    if (sync_required) {
      worker_thread* thread = spawn_worker_thread();
      thread->mAdaptor = this;
      thread->mEventId = event_id;
      thread->mTrans = &trans;
      thread->mWakeup.notify(t);
      return tlm::TLM_ACCEPTED;
    }
    else {
      destination->b_transport(trans, t);
    }
  }

  return tlm::TLM_UPDATED;
}

tlm::tlm_sync_enum
target_port_adaptor_impl::invoke_callback(scml2::callback_event_enum event_id, tlm::tlm_generic_payload& trans, sc_time& t)
{
  if (event_id < MAX_CBK_EVENT_ID_E) {
    return invoke_timing_callback(m_eventId2ProtoState[event_id], trans, t);
  }
  else {
    return tlm::TLM_UPDATED;
  }
}

void
target_port_adaptor_impl::
nb2b_thread(scml2::callback_event_enum event_id, tlm::tlm_generic_payload& trans)
{
  sc_core::sc_time t = sc_core::SC_ZERO_TIME;
  mappable_if* destination = get_destination(trans, false);
  if (destination) {
    destination->b_transport(trans, t);
  }

  // advance protocol state
  update_transaction(trans, t, event_id);
}


void target_port_adaptor_impl::worker_thread::single_shot_do_work() {
  sc_core::wait(mWakeup);
  assert(mAdaptor!=0 && mTrans!=0);
  mAdaptor->nb2b_thread(mEventId, *mTrans);
  delete this;
}

target_port_adaptor_impl::worker_thread* target_port_adaptor_impl::spawn_worker_thread() {
  worker_thread* t = new worker_thread;
  sc_core::sc_spawn(sc_bind(&worker_thread::single_shot_do_work, t), sc_core::sc_gen_unique_name("sc_worker_thread"));
  return t;
}

} // namespace scml2
