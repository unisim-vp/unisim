/*****************************************************************************
 *                   Copyright (C) 2013 Synopsys, Inc.                       *
 *       This software and the associated documentation are confidential     *
 *                  and proprietary to Synopsys, Inc.                        *
 *        Your use or disclosure of this software is subject                 *
 *      to the terms and conditions of a written license agreement           *
 *           between you, or your company, and Synopsys, Inc.                *
 *                                                                           *
 *****************************************************************************/

#include <scml2/initiator_port_adaptor_impl.h>
#include <scml2/axi_ft_initiator_port_adaptor.h>
#include <scml2/axi4_stream_initiator_port_adaptor.h>
#include <scml2/gft_initiator_port_adaptor.h>
#include <scml2/tlm2_gp_initiator_port_adaptor.h>

namespace scml2
{

//-----------------------------------------------------------------------------

initiator_port_adaptor*
initiator_port_adaptor::_create_adaptor(const std::string& protocol, const std::string& name, socket_if* sock)
{
  if (protocol == "TLM2_GP") {
    return new tlm2_gp_initiator_port_adaptor(name, sock);
  }
  else if (protocol == "AXI") {
    return new axi_ft_initiator_port_adaptor(name, sock);
  }
  else if (protocol == "AXI4Stream") {
    return new axi4_stream_initiator_port_adaptor(name, sock);
  }
  else if (protocol == "GFT") {
    return new gft_initiator_port_adaptor(name, sock);
  }
  else {
    cerr << "Failed to create initiator_port_adaptor : no adaptor available for protocol " << protocol << endl;
    //sc_exit();
    return NULL;
  }
}

//-----------------------------------------------------------------------------

initiator_port_adaptor_impl::initiator_port_adaptor_impl(const std::string& name, socket_if* sock)
  : port_adaptor_impl(name),
    initiator_port_adaptor(name),
    m_clk_control_if(NULL),
    m_clk_period_change_pending(false),
    mSocket(sock),
    // attribute default values
    m_read_capacity(1),
    m_write_capacity(1),
    m_rd_data_accept_cycles(0),
    m_wr_data_trigger_cycles(0),
    m_wr_rsp_accept_cycles(0)
{
  // link attributes
  m_attributes["read_capacity"] = (int*)&m_read_capacity;
  m_attributes["write_capacity"] = (int*)&m_write_capacity;
  m_attributes["rd_data_accept_cycles"] = (int*)&m_rd_data_accept_cycles;
  m_attributes["wr_data_trigger_cycles"] = (int*)&m_wr_data_trigger_cycles;
  m_attributes["wr_rsp_accept_cycles"] = (int*)&m_wr_rsp_accept_cycles;

  // setup event to signal when ready for clock period to change
  {
    sc_core::sc_spawn_options opts;
    opts.spawn_method();
    opts.set_sensitivity(&m_clk_change_event);
    opts.dont_initialize();
    sc_core::sc_spawn(sc_bind(&initiator_port_adaptor_impl::signal_ready_for_clock_change, this), sc_core::sc_gen_unique_name("signale_ready_for_clock_change"), &opts);
  }
  
}

initiator_port_adaptor_impl::~initiator_port_adaptor_impl()
{
  delete mSocket;
}

void
initiator_port_adaptor_impl::operator()(scml_clock_if* clk)
{
  port_adaptor_impl::operator()(clk);

  // register to handle clock period change handshaking
  m_clk_control_if = scml2::get_scml_clock_parameter_change_control(m_clk);
  if (m_clk_control_if) {
    m_clk_control_if->register_client(this);
  }
}

void
initiator_port_adaptor_impl::handle_clock_parameter_change_request(scml_clock_parameter_change_control_if* clk_control_if)
{
  assert(clk_control_if == m_clk_control_if);
  (void)clk_control_if;

  m_clk_period_change_pending = true;
  if (is_idle()) {
    m_clk_control_if->signal_ready_for_parameter_change(this);
  }
}

void
initiator_port_adaptor_impl::on_txn_complete(tlm::tlm_generic_payload& trans, const sc_time& t)
{
  trans.release();

  if (m_clk_period_change_pending && is_idle()) {
    m_clk_change_event.notify(t);
  }
}

void
initiator_port_adaptor_impl::signal_ready_for_clock_change()
{
  assert(m_clk_period_change_pending && is_idle());
  m_clk_control_if->signal_ready_for_parameter_change(this);
}

void
initiator_port_adaptor_impl::handle_clock_parameters_updated(scml_clock_if* clk)
{
  port_adaptor_impl::handle_clock_parameters_updated(clk);
  m_clk_period_change_pending = false;
}

tlm::tlm_generic_payload&
initiator_port_adaptor_impl::alloc_and_init_trans(tlm::tlm_command cmd)
{
  scml2::ft_generic_payload* payload = m_pool.claim();

  payload->set_command(cmd);
  payload->set_data_length(mSocket->get_bus_width() / 8);
  payload->set_streaming_width(mSocket->get_bus_width() / 8);
  payload->set_data_ptr(0);
  payload->set_byte_enable_ptr(0);
  payload->set_dmi_allowed(false);
  payload->set_response_status(tlm::TLM_INCOMPLETE_RESPONSE); 

  return *(tlm::tlm_generic_payload*)payload;
}

bool
initiator_port_adaptor_impl::send_transaction(tlm::tlm_generic_payload& payload)
{
  sc_time delay(0, SC_NS);
  return send_transaction(payload, delay);
}

std::string
initiator_port_adaptor_impl::get_mapped_name() const
{
  return (*mSocket).name();
}

void
initiator_port_adaptor_impl::b_transport(tlm::tlm_generic_payload& trans, sc_core::sc_time& t)
{
  (*mSocket).b_transport(trans, t);
}

bool
initiator_port_adaptor_impl::get_direct_mem_ptr(tlm::tlm_generic_payload& trans, tlm::tlm_dmi& dmiData)
{
  return (*mSocket).get_direct_mem_ptr(trans, dmiData);
}

unsigned int
initiator_port_adaptor_impl::transport_dbg(tlm::tlm_generic_payload& trans)
{
  return (*mSocket).transport_dbg(trans);
}

void
initiator_port_adaptor_impl::register_bw_direct_mem_if(tlm::tlm_bw_direct_mem_if* bwInterface)
{
  assert(bwInterface);
  mBwDirectMemIfs.insert(bwInterface);
}

void
initiator_port_adaptor_impl::unregister_bw_direct_mem_if(tlm::tlm_bw_direct_mem_if* bwInterface)
{
  mBwDirectMemIfs.erase(bwInterface);
}

void
initiator_port_adaptor_impl::invalidate_direct_mem_ptr(sc_dt::uint64 start_addr, sc_dt::uint64 end_addr)
{
  // TODO: invalidate DMI cache

  // Invalidate registered DMI handlers
  std::set<tlm::tlm_bw_direct_mem_if*>::iterator it = mBwDirectMemIfs.begin();
  std::set<tlm::tlm_bw_direct_mem_if*>::const_iterator end = mBwDirectMemIfs.end();
  for (; it != end; ++it) {
    (*it)->invalidate_direct_mem_ptr(start_addr, end_addr);
  }
}

} // namespace scml2
