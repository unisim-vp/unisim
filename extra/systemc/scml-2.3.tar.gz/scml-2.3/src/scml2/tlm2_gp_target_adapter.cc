// -*- C++ -*-
/*****************************************************************************
 *                   Copyright (C) 2009-2013 Synopsys, Inc.                  *
 *       This software and the associated documentation are confidential     *
 *                  and proprietary to Synopsys, Inc.                        *
 *        Your use or disclosure of this software is subject                 *
 *      to the terms and conditions of a written license agreement           *
 *           between you, or your company, and Synopsys, Inc.                *
 *                                                                           *
 *****************************************************************************/

#include "tlm2_gp_target_adapter.h"
#include <sysc/kernel/sc_dynamic_processes.h>

scml2::tlm2_gp_target_adapter_base::worker_thread::worker_thread() : mAdapter(0), mTrans(0) {}

void scml2::tlm2_gp_target_adapter_base::worker_thread::single_shot_do_work() {
  sc_core::wait(mWakeup);
  assert(mAdapter!=0 && mTrans!=0);
  mAdapter->nb2b_thread(*mTrans);
  delete this;
}

scml2::tlm2_gp_target_adapter_base::worker_thread* scml2::tlm2_gp_target_adapter_base::spawn_worker_thread() {
  worker_thread* t = new worker_thread;
  sc_core::sc_spawn(sc_bind(&worker_thread::single_shot_do_work, t), sc_core::sc_gen_unique_name("sc_worker_thread"));
  return t;
}

