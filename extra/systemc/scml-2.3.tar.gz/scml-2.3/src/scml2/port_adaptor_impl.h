/*****************************************************************************
 *                   Copyright (C) 2013 Synopsys, Inc.                       *
 *       This software and the associated documentation are confidential     *
 *                  and proprietary to Synopsys, Inc.                        *
 *        Your use or disclosure of this software is subject                 *
 *      to the terms and conditions of a written license agreement           *
 *           between you, or your company, and Synopsys, Inc.                *
 *                                                                           *
 *****************************************************************************/
#ifndef __PORT_ADAPTOR_IMPL_H__
#define __PORT_ADAPTOR_IMPL_H__

#include <map>
#include <scml2/port_adaptor.h>
#include <scml2/ft_channel.h>
#include <scml2_logging/stream.h>

/** Helper macros to provide consistent trace and log output for all derived port adaptors */
#define PORT_ADAPTOR_TRACE(payload, delay, msg)                       \
  if (m_trace_enabled) {                                              \
    (*trace_stream) << get_name()                                     \
                    << " : " << sc_time_stamp()                       \
                    << " : " << (sc_time_stamp() + delay)             \
                    << " : 0x" << std::hex << payload << std::dec     \
                    << " : " << __FUNCTION__                          \
                    << " : " << msg << std::endl;                     \
  }

#define PORT_ADAPTOR_ERROR(msg)               \
  cerr << "ERROR : " << get_name() << " : " << msg << endl;

#define PORT_ADAPTOR_TXN_ERROR(payload, delay, msg)           \
  cerr << "ERROR : " << get_name()                            \
       << " : " << sc_time_stamp()                            \
       << " : " << (sc_time_stamp() + delay)                  \
       << " : 0x" << std::hex << payload << std::dec          \
       << " : " << msg << std::endl;

namespace scml2
{

class port_adaptor_impl : protected scml_clock_observer
{
public:
  port_adaptor_impl(const std::string& name);
  virtual ~port_adaptor_impl();

  virtual std::string get_name() const = 0;
  virtual unsigned int get_bus_width() const = 0;
  unsigned int get_burst_size(tlm::tlm_generic_payload& trans) const;
  unsigned int get_burst_length(tlm::tlm_generic_payload& trans) const;

  void set_attribute(const std::string& name, int value);
  int get_attribute(const std::string& name);

  /* Clock interface */
  ///@{
  void operator()(scml_clock_if* clk);
  sc_time clock_cycles_to_time(unsigned int cycles) const;
  void set_clock_changed_callback(port_adaptor::clock_changed_callback_base* cbk);
  ///@}

  scml2::callback_event_enum get_event_id(unsigned int protocol_state) const;

  /** API to register a callback for the specified event in the transaction life cycle */
  bool set_timing_callback(callback_event_enum event_id, timing_callback_base* cb);

  /** Convenience function to return if there is any callback registered for a particular protocol state */
  bool has_callback(unsigned int protocol_state) const;

protected:
  std::string event_name(callback_event_enum event_id) const;
  virtual std::string state_name(unsigned int protocol_state) const;

  virtual void invoke_fwd_timing_callback(unsigned int protocol_state,
                                          tlm::tlm_generic_payload &trans,
                                          sc_time &t);

  // invocation API to handle callback lookup and invocation
  virtual tlm::tlm_sync_enum invoke_timing_callback(unsigned int protocol_state,
                                                    tlm::tlm_generic_payload &trans,
                                                    sc_time &t);

  // helper method to check clock period and generate error message if clock stopped
  inline void check_clk_period(std::string func)
  {
    if (m_clk && !m_clk->running()) {
      PORT_ADAPTOR_ERROR(func << " : bound clock " << m_clk->name() << " is not running");
      assert(false);
    }
  }

  /** scml_clock_observer interface implementation */
  ///@{
  virtual void handle_clock_parameters_updated(scml_clock_if*);
  virtual void handle_clock_deleted(scml_clock_if*);
  ///@}

  void setup_data_beat_avail_array(tlm::tlm_generic_payload& trans, unsigned int beat_count, unsigned int trigger_cycles);
  sc_time setup_data_beat_used_array(tlm::tlm_generic_payload& trans, unsigned int accept_cycles);
  void reset_beat_array_extensions(tlm::tlm_generic_payload& trans);

  /** tracing helpers */
  ///@{
  std::string byte_array_to_str(unsigned char* p_data, unsigned int length) const;
  ///@}
protected:
  static std::ostream*        trace_stream;
  bool                        m_trace_enabled;

  unsigned int                m_eventId2ProtoState[MAX_CBK_EVENT_ID_E]; // map callback_event_enum to protocol specific state
  std::map<std::string, int*> m_attributes;
  scml_clock_if*              m_clk;
  sc_time                     m_clk_period;

private:
  typedef std::map<unsigned int, timing_callback_base*> callback_map;

  port_adaptor::clock_changed_callback_base*  m_clk_changed_callback;
  callback_map m_callbacks;     // callback lookup by protocol specific state
};

} // namespace scml2

#endif  //__PORT_ADAPTOR_IMPL_H__
