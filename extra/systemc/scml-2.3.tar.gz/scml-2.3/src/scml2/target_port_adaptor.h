/*****************************************************************************
 *                   Copyright (C) 2013 Synopsys, Inc.                       *
 *       This software and the associated documentation are confidential     *
 *                  and proprietary to Synopsys, Inc.                        *
 *        Your use or disclosure of this software is subject                 *
 *      to the terms and conditions of a written license agreement           *
 *           between you, or your company, and Synopsys, Inc.                *
 *                                                                           *
 *****************************************************************************/
#ifndef __TARGET_PORT_ADAPTOR_H_
#define __TARGET_PORT_ADAPTOR_H_ 

#include "scml.h"
#include <scml2/mappable_if.h>
#include <scml2/memory_select_callback.h>
#include <scml2/port_adaptor.h>

namespace scml2
{

/*****************************************************************************
 * Name: target_port_adaptor
 *
 * Description: Base class for all target port adaptors.
 ****************************************************************************/
class SNPS_VP_API target_port_adaptor :
  public port_adaptor,
  public tlm::tlm_fw_transport_if<>,
  public tlm::tlm_bw_direct_mem_if
{
protected:
  /** Target socket wrapper class, used to access the templated socket
    * from the non-templated target port adaptor class. */
  class socket_if : public tlm::tlm_bw_nonblocking_transport_if<>,
                    public tlm::tlm_bw_direct_mem_if
  {
  public:
    virtual unsigned int get_bus_width() const = 0;
  };

  template <typename socket_type>
  class socket_wrapper : public socket_if {
  public:
    socket_wrapper(socket_type* socket) : m_target_socket(socket) { }
    virtual std::string name() const { return m_target_socket->name(); }
    virtual unsigned int get_bus_width() const { return m_target_socket->get_bus_width(); }

    virtual void invalidate_direct_mem_ptr(unsigned long long startRange, unsigned long long endRange)
    {
      (*m_target_socket)->invalidate_direct_mem_ptr(startRange, endRange);
    }

    virtual tlm::tlm_sync_enum nb_transport_bw(tlm::tlm_generic_payload& trans, tlm::tlm_phase& phase, sc_time& t)
    {
      return (*m_target_socket)->nb_transport_bw(trans, phase, t);
    }

  private:
    socket_type* m_target_socket;
  };

protected:

  // Port adaptor is not constructed directly - use the create API instead
  target_port_adaptor(const std::string& name) : port_adaptor(name) { }

  static target_port_adaptor* _create_adaptor(const std::string& protocol, const std::string& name, socket_if* sock);

public:
  template <typename socket_type>
  static target_port_adaptor* create_adaptor(const std::string& protocol, const std::string& name, socket_type* socket)
  {
    // create the adaptor but don't bind to the socket yet
    return _create_adaptor(protocol, name, new socket_wrapper<socket_type>(socket));
  }

  template <typename socket_type>
  static target_port_adaptor* create(const std::string& protocol, const std::string& name, socket_type* socket)
  {
    target_port_adaptor* adaptor = create_adaptor(protocol, name, socket);

    // Set protocol on socket. Ideally would be done in the adaptor instead but templated socket makes it awkward
    if (protocol == "AXI") {
      assert(is_ft_socket(socket));
      (*socket).template set_protocol<scml2::axi_protocol_state_extension>(protocol);
    }
    else if (protocol == "AXI4Stream") {
      assert(is_ft_socket(socket));
      (*socket).template set_protocol<scml2::axi4_stream_protocol_state_extension>(protocol);
    }
    else if (protocol == "GFT") {
      assert(is_ft_socket(socket));
      (*socket).template set_protocol<scml2::gft_protocol_state_extension>(protocol);
    }

    socket->bind(*adaptor);

    return adaptor;
  }

  template <typename socket_type>
  static target_port_adaptor* create(const std::string& name, socket_type* socket)
  {
    // try to lookup protocol from the port property
    std::string protocol;
    scml_property_registry &inst = scml_property_registry::inst();
    if (inst.hasProperty(scml_property_registry::PROTOCOL, scml_property_registry::STRING,
                          socket->name(), "ft_protocol_tag")) {
      protocol = inst.getStringProperty(scml_property_registry::PROTOCOL,
                            socket->name(), "ft_protocol_tag");
    }
    else {
      cerr << "No ft_protocol_tag property for socket " << socket->name() << ", defaulting to tlm2_gp" << endl;
      protocol = "TLM2_GP";
    }

    return create(protocol, name, socket);
  }

  ~target_port_adaptor() {}

  /** Bind the adaptor to a memory */
  using port_adaptor::operator();
  virtual void operator()(mappable_if& destination) = 0;
  virtual void set_select_callback(memory_select_callback_base* cb) = 0;

  static bool set_target_callback(mappable_if& dest, callback_event_enum event_id, timing_callback_base* cb);
};

// API to set select and timing callbacks
template <typename C>
inline
void
set_select_callback(target_port_adaptor& adaptor, C* c, typename memory_select_callback<C>::CallbackType cb, const std::string& name)
{
  adaptor.set_select_callback(new memory_select_callback<C>(*c, cb, name));
}

template <typename C>
inline
bool set_timing_callback(mappable_if& dest, callback_event_enum event_id, C* c, typename timing_callback0<C>::CallbackType cb)
{
  assert(c);
  return target_port_adaptor::set_target_callback(dest, event_id, create_timing_callback(c, cb));
}

template <typename C, typename A>
inline
bool set_timing_callback(mappable_if& dest, callback_event_enum event_id, C* c, typename timing_callback1<C,A>::CallbackType cb, A a)
{
  assert(c);
  return target_port_adaptor::set_target_callback(dest, event_id, create_timing_callback(c, cb, a));
}

} // namespace scml2

#endif  //__TARGET_PORT_ADAPTOR_H_
