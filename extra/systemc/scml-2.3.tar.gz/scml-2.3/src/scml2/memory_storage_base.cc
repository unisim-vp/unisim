/*****************************************************************************
 *                   Copyright (C) 2009-2010 Synopsys, Inc.                  *
 *       This software and the associated documentation are confidential     *
 *                  and proprietary to Synopsys, Inc.                        *
 *        Your use or disclosure of this software is subject                 *
 *      to the terms and conditions of a written license agreement           *
 *           between you, or your company, and Synopsys, Inc.                *
 *                                                                           *
 *****************************************************************************/
#include <scml2/memory_storage_base.h>
#include <scml2/memory_heap_storage.h>

namespace scml2 {

memory_storage_base::
memory_storage_base()
{
}

memory_storage_base::
~memory_storage_base()
{
}

}
