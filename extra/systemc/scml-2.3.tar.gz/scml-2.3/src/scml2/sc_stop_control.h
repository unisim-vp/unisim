/*****************************************************************************
 *                   Copyright (C) 2009-2013 Synopsys, Inc.                  *
 *       This software and the associated documentation are confidential     *
 *                  and proprietary to Synopsys, Inc.                        *
 *        Your use or disclosure of this software is subject                 *
 *      to the terms and conditions of a written license agreement           *
 *           between you, or your company, and Synopsys, Inc.                *
 *                                                                           *
 *****************************************************************************/
#ifndef SCML2_SC_STOP_CONTROL_H
#define SCML2_SC_STOP_CONTROL_H

#include <scml2_logging/snps_vp_dll.h>
#include <vector>

namespace scml2 {
  /** The SCML2 sc_stop control allows the implementation of a
   *  decentralized scheme for finishing the SystemC simulation. There
   *  can be multiple controlling objects (e.g. sc_modules,
   *  represented by a VOID pointer handle) that want the simulation
   *  to finish (by a centralized call of sc_stop()) when they are
   *  done with their jobs. The scheme ensures that the simulation
   *  continues as long as not all controlling objects have signaled
   *  that they are done with their jobs.
   *
   *  An object that wants to participate with this scheme must be
   *  registered via a call to register_sc_stop_controller(). When the
   *  object is done with its jobs and wants to request finish of the
   *  simulation, it must be deregistered via a call to
   *  deregister_sc_stop_controller(). When the last object is
   *  deregistered, sc_stop() is called by the sc_stop control. */
  
  /** Register a controlling object (represented by handle) with the
   *  sc_stop control. When the last registered object is
   *  deregistered, then sc_stop() will be called by the sc_stop
   *  control. A handle must only be registered once. */
  SNPS_VP_API void register_sc_stop_controller(void* handle);
  /** Deregister a controlling object (represented by handle) from the
   *  sc_stop control. The object must have been registered before via
   *  a call to register_sc_stop_controller(). returns true when the
   *  last registered object is deregistered. In that case sc_stop()
   *  has been called by the sc_stop control. Returns false if there
   *  are still other registered objects. */
  SNPS_VP_API bool deregister_sc_stop_controller(void* handle);
  /** Returns the number of objects that have been registered via
   *  register_sc_stop_controller() and that have not yet been
   *  deregistered via deregister_sc_stop_controller(). */
  SNPS_VP_API int get_num_registered_sc_stop_controllers();
  /** Collect all objects in the result vector that have been
   *  registered via register_sc_stop_controller() and that have not
   *  yet been deregistered via deregister_sc_stop_controller(). */
  SNPS_VP_API void collect_registered_sc_stop_controllers(std::vector<void*>& result);
}

#endif

