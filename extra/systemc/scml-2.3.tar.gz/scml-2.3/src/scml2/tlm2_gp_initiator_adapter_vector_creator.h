/*****************************************************************************
 *                   Copyright (C) 2009-2013 Synopsys, Inc.                  *
 *       This software and the associated documentation are confidential     *
 *                  and proprietary to Synopsys, Inc.                        *
 *        Your use or disclosure of this software is subject                 *
 *      to the terms and conditions of a written license agreement           *
 *           between you, or your company, and Synopsys, Inc.                *
 *                                                                           *
 *****************************************************************************/
#ifndef SCML2_TLM2_GP_INITIATOR_ADAPTER_CREATOR_H
#define SCML2_TLM2_GP_INITIATOR_ADAPTER_CREATOR_H

#include <systemc.h>
#include <scml2/tlm2_gp_initiator_adapter.h>

namespace scml2 {

template <unsigned int BUSWIDTH, int N = 1, sc_core::sc_port_policy POL = sc_core::SC_ONE_OR_MORE_BOUND>
class tlm2_gp_initiator_adapter_vector_creator
{
public:
  typedef tlm2_gp_initiator_adapter<BUSWIDTH, N, POL> adapter_type;
  typedef tlm::tlm_initiator_socket<BUSWIDTH, tlm::tlm_base_protocol_types, N, POL> socket_type;

  tlm2_gp_initiator_adapter_vector_creator(sc_core::sc_vector<socket_type>& sockets) : mSockets(sockets) {
  }

  adapter_type* operator()(const char* prefix, size_t i) {
    return new adapter_type(prefix, mSockets[i]);
  }

private:
  sc_core::sc_vector<socket_type>& mSockets;
};

template <unsigned int BUSWIDTH, int N, sc_core::sc_port_policy POL>
inline tlm2_gp_initiator_adapter_vector_creator<BUSWIDTH, N, POL>
create_tlm2_gp_initiator_adapter_vector_creator(sc_core::sc_vector<tlm::tlm_initiator_socket<BUSWIDTH, tlm::tlm_base_protocol_types, N, POL> >& sockets) {
  return tlm2_gp_initiator_adapter_vector_creator<BUSWIDTH, N, POL>(sockets);
}


}

#endif
