#ifndef __TLM2_GP_MM_IFS_H__
#define __TLM2_GP_MM_IFS_H__

#include <tlm.h>

/******************************************************************************
 * Name : tlm2_gp_mm_ifs
 * Description : This files defines the interfaces used by memory manager and 
 *               the memory manager creators.
 * ****************************************************************************/

namespace scml2 {

class tlm2_gp_mm_if : public tlm::tlm_mm_interface
{
  public:
    virtual tlm::tlm_generic_payload* claim() = 0 ;
};

class tlm2_gp_mm_creator_if 
{
  public:
	virtual ~tlm2_gp_mm_creator_if() {}
    virtual tlm2_gp_mm_if* create_mm () = 0; 
};

}//namespace scml2

#endif // __TLM2_GP_MM_IFS_H__
