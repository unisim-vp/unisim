/*****************************************************************************
 *                   Copyright (C) 2009-2010 Synopsys, Inc.                  *
 *       This software and the associated documentation are confidential     *
 *                  and proprietary to Synopsys, Inc.                        *
 *        Your use or disclosure of this software is subject                 *
 *      to the terms and conditions of a written license agreement           *
 *           between you, or your company, and Synopsys, Inc.                *
 *                                                                           *
 *****************************************************************************/
#ifndef SCML2_CALLBACK_MACRO_H
#define SCML2_CALLBACK_MACRO_H

#define SCML2_CALLBACK(func) this, &SC_CURRENT_USER_MODULE::func, #func

#endif
