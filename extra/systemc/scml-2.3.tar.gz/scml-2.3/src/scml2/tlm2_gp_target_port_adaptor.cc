/*****************************************************************************
 *                   Copyright (C) 2013 Synopsys, Inc.                       *
 *       This software and the associated documentation are confidential     *
 *                  and proprietary to Synopsys, Inc.                        *
 *        Your use or disclosure of this software is subject                 *
 *      to the terms and conditions of a written license agreement           *
 *           between you, or your company, and Synopsys, Inc.                *
 *                                                                           *
 *****************************************************************************/
#include <scml2_tlm2/snps_tlm2_extensions/snps_tlm2_extensions.h>
#include <scml2/tlm2_gp_target_port_adaptor.h>

namespace scml2
{

tlm2_gp_target_port_adaptor::tlm2_gp_target_port_adaptor(const std::string& name, target_port_adaptor::socket_if* sock)
 :  target_port_adaptor_impl(name, sock),
    m_response_channel(this, &tlm2_gp_target_port_adaptor::begin_response),
    m_inside_nb_transport_fw(false),
    m_pending_bw_state(false)
{
  // override default attribute values
  m_rd_cmd_accept_cycles = 0;
  m_wr_cmd_accept_cycles = 0;
  m_wr_rsp_trigger_cycles = 0;

  // Just re-use the callback states
  m_eventId2ProtoState[RD_ADDR_START]       = RD_ADDR_START;
  m_eventId2ProtoState[RD_ADDR_END]         = RD_ADDR_END;
  m_eventId2ProtoState[RD_DATA_LAST_START]  = RD_DATA_LAST_START;
  m_eventId2ProtoState[RD_DATA_LAST_END]    = RD_DATA_LAST_END;
  m_eventId2ProtoState[WR_ADDR_START]       = WR_ADDR_START;
  m_eventId2ProtoState[WR_ADDR_END]         = WR_ADDR_END;
  m_eventId2ProtoState[WR_RSP_START]        = WR_RSP_START;
  m_eventId2ProtoState[WR_RSP_END]          = WR_RSP_END;
}

bool
tlm2_gp_target_port_adaptor::is_behavior_event(scml2::callback_event_enum event_id) const
{
  return ((event_id == RD_ADDR_START) || (event_id == WR_ADDR_START));
}

tlm::tlm_phase_enum
tlm2_gp_target_port_adaptor::event_id_to_phase(scml2::callback_event_enum event_id)
{
  switch (event_id)
  {
    case RD_ADDR_START:
    case WR_ADDR_START:
      return tlm::BEGIN_REQ;

    case RD_ADDR_END:
    case WR_ADDR_END:
      return tlm::END_REQ;

    case RD_DATA_LAST_START:
    case WR_RSP_START:
      return tlm::BEGIN_RESP;

    case RD_DATA_LAST_END:
    case WR_RSP_END:
      return tlm::END_RESP;

    default:
      return tlm::UNINITIALIZED_PHASE;
  }
}

scml2::callback_event_enum
tlm2_gp_target_port_adaptor::phase_to_event_id(tlm::tlm_generic_payload& trans, const tlm::tlm_phase& phase)
{
  switch (phase)
  {
    case tlm::BEGIN_REQ:  return trans.is_read() ? scml2::RD_ADDR_START : scml2::WR_ADDR_START;
    case tlm::END_REQ:    return trans.is_read() ? scml2::RD_ADDR_END : scml2::WR_ADDR_END;
    case tlm::BEGIN_RESP: return trans.is_read() ? scml2::RD_DATA_LAST_START : scml2::WR_RSP_START;
    case tlm::END_RESP:   return trans.is_read() ? scml2::RD_DATA_LAST_END : scml2::WR_RSP_END;
    default:
      return scml2::CBK_EVENT_NONE;
  }
}

std::string
tlm2_gp_target_port_adaptor::state_name(unsigned int protocol_state) const
{
  switch ((scml2::callback_event_enum)protocol_state)
  {
    case RD_ADDR_START:
    case WR_ADDR_START:
      return "BEGIN_REQ";

    case RD_ADDR_END:
    case WR_ADDR_END:
      return "END_REQ";

    case RD_DATA_LAST_START:
    case WR_RSP_START:
      return "BEGIN_RESP";

    case RD_DATA_LAST_END:
    case WR_RSP_END:
      return "END_RESP";

    default:
      return port_adaptor_impl::state_name(protocol_state);
  }
}

/** API invoked from the user to advance the protocol state */
bool
tlm2_gp_target_port_adaptor::update_transaction(tlm::tlm_generic_payload& trans, sc_time& t, scml2::callback_event_enum event_id)
{
  // verify that user is attempting a valid state transition
  scml2::callback_event_enum current_id = m_payloads[&trans].state;
  bool state_ok = false;

  switch (current_id) {
    case scml2::RD_ADDR_START:      state_ok = (event_id == scml2::RD_ADDR_END || event_id == scml2::RD_DATA_LAST_START); break;
    case scml2::RD_ADDR_END:        state_ok = (event_id == scml2::RD_DATA_LAST_START); break;
    case scml2::WR_ADDR_START:      state_ok = (event_id == scml2::WR_ADDR_END || event_id == scml2::WR_RSP_START); break;
    case scml2::WR_ADDR_END:        state_ok = (event_id == scml2::WR_RSP_START); break;
    default:
      break;
  }
  if (!state_ok) {
    PORT_ADAPTOR_TXN_ERROR((&trans), t, "update_transaction invoked with invalid event: "
      << event_name(event_id) << ", current state is " << event_name(current_id));
    return false;
  }

  // set the new state and advance the protocol state machine
  m_payloads[&trans].state = event_id;
  return update_transaction(trans, t);
}

bool
tlm2_gp_target_port_adaptor::update_transaction(tlm::tlm_generic_payload& trans, sc_time& t)
{
  PORT_ADAPTOR_TRACE((&trans), t, event_name(m_payloads[&trans].state));

  tlm::tlm_phase phase = event_id_to_phase(m_payloads[&trans].state);

  if (m_inside_nb_transport_fw) {
    // wait to process this state until we unwind back to nb_transport_fw
    if (m_pending_bw_state)
    {
      PORT_ADAPTOR_TXN_ERROR((&trans), t, "update_transaction has been invoked but the previous state has not yet been processed.");
      return false;
    }
    m_pending_bw_state = true;
    m_pending_bw_state_time = t;
  }
  else if (phase == tlm::BEGIN_RESP) {
    // queue responses
    m_response_channel.request(trans, t, true);
  }
  else {
    invoke_fwd_timing_callback(m_payloads[&trans].state, trans, t);
    mSocket->nb_transport_bw(trans, phase, t);
  }

  return true;
}

void
tlm2_gp_target_port_adaptor::begin_response(tlm::tlm_generic_payload& trans, sc_time& t)
{
  PORT_ADAPTOR_TRACE((&trans), t, event_name(m_payloads[&trans].state));

  // channel has been captured, can now forward to socket and advance protocol state machine
  invoke_fwd_timing_callback(m_payloads[&trans].state, trans, t);

  tlm::tlm_phase phase = tlm::BEGIN_RESP;
  tlm::tlm_sync_enum result = mSocket->nb_transport_bw(trans, phase, t);
  if (result == tlm::TLM_COMPLETED ||
     (result == tlm::TLM_UPDATED && phase == tlm::END_RESP)) {
    // transaction finished
    phase = tlm::END_RESP;
    process_fw_states(trans, phase, t);
  }
}

/* Backward response call from the target */
tlm::tlm_sync_enum
tlm2_gp_target_port_adaptor::nb_transport_fw(tlm::tlm_generic_payload& trans, tlm::tlm_phase& phase, sc_time& t)
{
  scml2::callback_event_enum event_id = phase_to_event_id(trans, phase);

  PORT_ADAPTOR_TRACE((&trans), t, event_name(event_id));

  check_clk_period("nb_transport_fw");

  // ignore unrecognised phases
  if (event_id == scml2::CBK_EVENT_NONE) {
    return tlm::TLM_ACCEPTED;
  }

  m_inside_nb_transport_fw = true;
  m_pending_bw_state = false;

  if (m_payloads.find(&trans) == m_payloads.end()) {
    trans.acquire();
  }

  tlm::tlm_sync_enum return_status = process_fw_states(trans, phase, t);

  if (m_pending_bw_state) {
    m_pending_bw_state = false;
    phase = event_id_to_phase(m_payloads[&trans].state);
    t = m_pending_bw_state_time;
    return_status = tlm::TLM_UPDATED;
  }

  if (return_status == tlm::TLM_UPDATED) {
    invoke_fwd_timing_callback(m_payloads[&trans].state, trans, t);
  }

  m_inside_nb_transport_fw = false;
  return return_status;
}

tlm::tlm_sync_enum
tlm2_gp_target_port_adaptor::process_fw_states(tlm::tlm_generic_payload& trans, tlm::tlm_phase& phase, sc_time& t)
{
  PORT_ADAPTOR_TRACE((&trans), t, event_name(phase_to_event_id(trans, phase)));

  scml2::callback_event_enum event_id = phase_to_event_id(trans, phase);
  m_payloads[&trans].state = event_id;

  // invoke the callback if associated with this phase, return status indicates
  // whether we advance the phase ourselves or wait for owner to invoke
  // update_transaction
  tlm::tlm_sync_enum return_status = invoke_callback(event_id, trans, t);
  if ((phase != tlm::END_RESP) && (return_status != tlm::TLM_UPDATED)) {
    return return_status;
  }

  // advance protocol state
  return_status = advance_state(trans, t);
  if (return_status == tlm::TLM_UPDATED) {
    phase = event_id_to_phase(m_payloads[&trans].state);
  }
  return return_status;
}

tlm::tlm_sync_enum
tlm2_gp_target_port_adaptor::advance_state(tlm::tlm_generic_payload& trans, sc_time& t)
{
  scml2::callback_event_enum event_id = m_payloads[&trans].state;

  // advance protocol state
  switch (event_id) {
    case scml2::RD_ADDR_START:
      t += m_clk_period * m_rd_cmd_accept_cycles;

      // if read address callback is registered, it is up to the user
      // model to handle behavior and advance to read data state.
      if (has_callback(scml2::RD_ADDR_START)) {
        event_id = scml2::RD_ADDR_END;
      }
      else {
        // invoke behavior callback internally and return read data
        if (do_invoke_callback(scml2::RD_DATA_LAST_START, trans, t) == tlm::TLM_ACCEPTED)
          return tlm::TLM_ACCEPTED;

        t += m_clk_period * m_rd_data_trigger_cycles;
        event_id = scml2::RD_DATA_LAST_START;
      }
      break;

    case scml2::WR_ADDR_START:
      t += m_clk_period * m_wr_cmd_accept_cycles;

      // if write address callback is registered, it is up to the user
      // model to handle behavior and advance to write response state
      if (has_callback(scml2::WR_ADDR_START)) {
        event_id = scml2::WR_ADDR_END;
      }
      else {
        // invoke behavior callback internally and return write response
        if (do_invoke_callback(scml2::WR_RSP_START, trans, t) == tlm::TLM_ACCEPTED)
          return tlm::TLM_ACCEPTED;

        t += m_clk_period * m_wr_rsp_trigger_cycles;
        event_id = scml2::WR_RSP_START;
      }
      break;

    case scml2::RD_DATA_LAST_END:
    case scml2::WR_RSP_END:
      // transaction is complete
      m_payloads.erase(&trans);
      if (m_response_channel.is_captured_by(trans)) {
        m_response_channel.release(t);
      }
      trans.release();
      return tlm::TLM_COMPLETED;

    default:
      PORT_ADAPTOR_TXN_ERROR((&trans), t, "Received invalid event: " << event_name(event_id));
      return tlm::TLM_ACCEPTED;
  }

  m_payloads[&trans].state = event_id;
  return tlm::TLM_UPDATED;
}

} // namespace scml2
