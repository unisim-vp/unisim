/*****************************************************************************
 *                   Copyright (C) 2013 Synopsys, Inc.                       *
 *       This software and the associated documentation are confidential     *
 *                  and proprietary to Synopsys, Inc.                        *
 *        Your use or disclosure of this software is subject                 *
 *      to the terms and conditions of a written license agreement           *
 *           between you, or your company, and Synopsys, Inc.                *
 *                                                                           *
 *****************************************************************************/
#ifndef __INITIATOR_PORT_ADAPTOR_H__
#define __INITIATOR_PORT_ADAPTOR_H__ 

#include <set>
#include "scml.h"
#include <scml2/mappable_if.h>
#include <scml2/port_adaptor.h>

namespace scml2
{

/*****************************************************************************
 * Name: initiator_port_adaptor
 *
 * Description: Base class for all initiator port adaptors.
 ****************************************************************************/
class SNPS_VP_API initiator_port_adaptor :  public port_adaptor,
                                            public mappable_if,
                                            public tlm::tlm_bw_transport_if<> {

protected:
  /** Initiator socket wrapper class, used to access the templated socket
    * from the non-templated initiator port adaptor class. */
  class socket_if : public tlm::tlm_fw_transport_if<>
  {
  public:
    virtual std::string name() const = 0;
    virtual unsigned int get_bus_width() const = 0;
  };

  template <typename socket_type>
  class socket_wrapper : public socket_if {
  public:
    socket_wrapper(socket_type* socket) : m_init_socket(socket) { }
    virtual std::string name() const { return m_init_socket->name(); }
    virtual unsigned int get_bus_width() const { return m_init_socket->get_bus_width(); }

    virtual bool get_direct_mem_ptr(tlm::tlm_generic_payload& trans, tlm::tlm_dmi& dmiData)
    {
      return (*m_init_socket)->get_direct_mem_ptr(trans, dmiData);
    }

    virtual unsigned int transport_dbg(tlm::tlm_generic_payload& trans)
    {
      return (*m_init_socket)->transport_dbg(trans);
    }

    virtual void b_transport(tlm::tlm_generic_payload& trans, sc_time& t)
    {
      (*m_init_socket)->b_transport(trans, t);
    }

    virtual tlm::tlm_sync_enum nb_transport_fw(tlm::tlm_generic_payload& trans, tlm::tlm_phase& phase, sc_time& t)
    {
      return (*m_init_socket)->nb_transport_fw(trans, phase, t);
    }

  private:
    socket_type* m_init_socket;
  };

protected:
  // Port adaptor is not constructed directly - use the create API instead
  initiator_port_adaptor(const std::string& name) : port_adaptor(name) { }

  static initiator_port_adaptor* _create_adaptor(const std::string& protocol, const std::string& name, socket_if* socket);

public:
  template <typename socket_type>
  static initiator_port_adaptor* create_adaptor(const std::string& protocol, const std::string& name, socket_type* socket)
  {
    // create the adaptor but don't bind to the socket yet
    return _create_adaptor(protocol, name, new socket_wrapper<socket_type>(socket));
  }

  template <typename socket_type>
  static initiator_port_adaptor* create(const std::string& protocol, const std::string& name, socket_type* socket)
  {
    initiator_port_adaptor* adaptor = create_adaptor(protocol, name, socket);

    // Set protocol on socket. Ideally would be done in the adaptor instead but templated socket makes it awkward
    if (protocol == "AXI") {
      assert(is_ft_socket(socket));
      (*socket).template set_protocol<scml2::axi_protocol_state_extension>(protocol);
    }
    else if (protocol == "AXI4Stream") {
      assert(is_ft_socket(socket));
      (*socket).template set_protocol<scml2::axi4_stream_protocol_state_extension>(protocol);
    }
    else if (protocol == "GFT") {
      assert(is_ft_socket(socket));
      (*socket).template set_protocol<scml2::gft_protocol_state_extension>(protocol);
    }

    socket->bind(*adaptor);

    return adaptor;
  }

  template <typename socket_type>
  static initiator_port_adaptor* create(const std::string& name, socket_type* socket)
  {
    // try to lookup protocol from the port property
    std::string protocol;
    scml_property_registry &inst = scml_property_registry::inst();
    if (inst.hasProperty(scml_property_registry::PROTOCOL, scml_property_registry::STRING,
                          socket->name(), "ft_protocol_tag")) {
      protocol = inst.getStringProperty(scml_property_registry::PROTOCOL,
                            socket->name(), "ft_protocol_tag");
    }
    else {
      cerr << "No ft_protocol_tag property for socket " << socket->name() << ", defaulting to tlm2_gp" << endl;
      protocol = "TLM2_GP";
    }

    return create(protocol, name, socket);
  }

  ~initiator_port_adaptor() { }

  /** Clock interface */
  virtual bool is_idle() const = 0;   /** Indicates whether there are any active transfers on the port adaptor */

  /** API to request a transaction object */
  virtual tlm::tlm_generic_payload& alloc_and_init_trans(tlm::tlm_command cmd) = 0;

  /** API to send a transaction over the bus */
  virtual bool send_transaction(tlm::tlm_generic_payload& payload) = 0;
  virtual bool send_transaction(tlm::tlm_generic_payload& payload, sc_time& delay) = 0;
};

} // namespace scml2

#endif  //__INITIATOR_PORT_ADAPTOR_H__
