/*****************************************************************************
 *                   Copyright (C) 2009-2010 Synopsys, Inc.                  *
 *       This software and the associated documentation are confidential     *
 *                  and proprietary to Synopsys, Inc.                        *
 *        Your use or disclosure of this software is subject                 *
 *      to the terms and conditions of a written license agreement           *
 *           between you, or your company, and Synopsys, Inc.                *
 *                                                                           *
 *****************************************************************************/
#include <scml2/memory_bitfields_read_callback.h>

#include <scml2/reg.h>
#include <scml2/bitfield.h>

namespace scml2 {

template <typename DT>
bool
memory_bitfields_read_callback<DT>::
has_never_syncing_behavior() const
{
  return mRegister.has_never_syncing_bitfield_read_behavior();
}

template <typename DT>
inline
void
memory_bitfields_read_callback<DT>::
execute(tlm::tlm_generic_payload& trans, sc_core::sc_time& t)
{
  this->unroll_to_word_access(trans, t);
}

template <typename DT>
bool
memory_bitfields_read_callback<DT>::
process_unrolled_access(DT& data,
                        const DT& byteEnables,
                        sc_core::sc_time& t,
                        const tlm2_gp_extensions&)
{
  return mRegister.get_with_triggering_bitfield_callbacks(data, byteEnables, t);
}

#ifdef _WIN32
#define SCML2_INSTANTIATE_TEMPLATE(type)				\
  template class SNPS_VP_API memory_bitfields_read_callback<type>;
#else
#define SCML2_INSTANTIATE_TEMPLATE(type)		\
  template class memory_bitfields_read_callback<type>;
#endif
SCML2_FOR_EACH_DT(SCML2_INSTANTIATE_TEMPLATE)
#undef SCML2_INSTANTIATE_TEMPLATE

}
