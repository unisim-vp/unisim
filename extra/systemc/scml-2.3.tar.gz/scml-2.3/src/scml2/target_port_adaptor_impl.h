/*****************************************************************************
 *                   Copyright (C) 2013 Synopsys, Inc.                       *
 *       This software and the associated documentation are confidential     *
 *                  and proprietary to Synopsys, Inc.                        *
 *        Your use or disclosure of this software is subject                 *
 *      to the terms and conditions of a written license agreement           *
 *           between you, or your company, and Synopsys, Inc.                *
 *                                                                           *
 *****************************************************************************/
#ifndef __TARGET_PORT_ADAPTOR_IMPL_H_
#define __TARGET_PORT_ADAPTOR_IMPL_H_ 

#include <scml2/port_adaptor_impl.h>
#include <scml2/target_port_adaptor.h>

namespace scml2
{

/*****************************************************************************
 * Name: target_port_adaptor
 *
 * Description: Base class for all target port adaptors.
 ****************************************************************************/
class target_port_adaptor_impl :
  public port_adaptor_impl,
  public target_port_adaptor
{
public:
  target_port_adaptor_impl(const std::string& name, target_port_adaptor::socket_if* sock);
  ~target_port_adaptor_impl();

  /** Port Adaptor interface */
  virtual std::string get_name() const { return name(); }
  virtual unsigned int get_bus_width() const { return mSocket->get_bus_width(); }
  virtual unsigned int get_burst_length(tlm::tlm_generic_payload& trans) const { return port_adaptor_impl::get_burst_length(trans); }

  /** Set attributes */
  virtual void set_attribute(const std::string& name, int value) { port_adaptor_impl::set_attribute(name, value); }
  virtual int get_attribute(const std::string& name) { return port_adaptor_impl::get_attribute(name); }

  /** Clock interface */
  ///@{
  using port_adaptor::operator();
  virtual void operator()(scml_clock_if* clk) { return port_adaptor_impl::operator()(clk); }
  virtual sc_time clock_cycles_to_time(unsigned int cycles) const { return port_adaptor_impl::clock_cycles_to_time(cycles); }
  virtual void set_clock_changed_callback(port_adaptor::clock_changed_callback_base* cbk) { return port_adaptor_impl::set_clock_changed_callback(cbk); }
  ///@}

  virtual scml2::callback_event_enum get_event_id(unsigned int protocol_state) const { return port_adaptor_impl::get_event_id(protocol_state); }

  /** API to register a callback for the specified event in the transaction life cycle */
  virtual bool set_timing_callback(callback_event_enum event_id, timing_callback_base* cb) { return port_adaptor_impl::set_timing_callback(event_id, cb); }

  /** Convenience function to return if there is any callback registered for a particular protocol state */
  virtual bool has_callback(unsigned int protocol_state) const { return port_adaptor_impl::has_callback(protocol_state); }

  /** Bind the adaptor to a memory */
  virtual void operator()(mappable_if& destination);
  virtual void set_select_callback(memory_select_callback_base* cb);


  /** fw transport interface */
  virtual void b_transport(tlm::tlm_generic_payload& trans, sc_time& delay);
  virtual unsigned int transport_dbg(tlm::tlm_generic_payload& trans);
  virtual bool get_direct_mem_ptr(tlm::tlm_generic_payload& trans, tlm::tlm_dmi& dmi_data);

  virtual void invalidate_direct_mem_ptr(unsigned long long startRange, unsigned long long endRange);

protected:
  mappable_if* get_destination(tlm::tlm_generic_payload& payload, bool error_if_not_bound) const;
  virtual bool is_behavior_event(scml2::callback_event_enum event_id) const;
  tlm::tlm_sync_enum do_invoke_callback(scml2::callback_event_enum event_id, tlm::tlm_generic_payload& trans, sc_time& t);
  tlm::tlm_sync_enum invoke_callback(scml2::callback_event_enum event_id, tlm::tlm_generic_payload& trans, sc_time& t);
  void nb2b_thread(scml2::callback_event_enum event_id, tlm::tlm_generic_payload& trans);
  virtual tlm::tlm_sync_enum advance_state(tlm::tlm_generic_payload& trans, sc_time& t) = 0;

  class worker_thread {
  public:
    sc_core::sc_event          mWakeup;
    target_port_adaptor_impl*  mAdaptor;
    scml2::callback_event_enum mEventId;
    tlm::tlm_generic_payload*  mTrans;

    worker_thread() : mAdaptor(0), mEventId(scml2::MAX_CBK_EVENT_ID_E), mTrans(0) { }
    void single_shot_do_work();
  };

  static worker_thread* spawn_worker_thread();

protected:
  socket_if *mSocket;
  mappable_if* mDestination;
  int mBoundDestinations;
  memory_select_callback_base* mSelectCallback;
  mutable logging::stream mError;

  // attributes
  unsigned int m_read_capacity;
  unsigned int m_write_capacity;
  unsigned int m_rd_cmd_accept_cycles;
  unsigned int m_rd_data_trigger_cycles;
  unsigned int m_wr_cmd_accept_cycles;
  unsigned int m_wr_data_accept_cycles;
  unsigned int m_wr_rsp_trigger_cycles;

  static int gMaxThreadsInPool;
  typedef std::list<worker_thread*> tWorkerThreads;
  static tWorkerThreads* gWorkerThreads;
};

} // namespace scml2

#endif  //__TARGET_PORT_ADAPTOR_IMPL_H_
