/*****************************************************************************
 *                   Copyright (C) 2014 Synopsys, Inc.                       *
 *       This software and the associated documentation are confidential     *
 *                  and proprietary to Synopsys, Inc.                        *
 *        Your use or disclosure of this software is subject                 *
 *      to the terms and conditions of a written license agreement           *
 *           between you, or your company, and Synopsys, Inc.                *
 *                                                                           *
 *****************************************************************************/
#include <scml2_tlm2/snps_tlm2_extensions/snps_tlm2_extensions.h>
#include <scml2/tlm2_gp_initiator_port_adaptor.h>

namespace scml2
{

tlm2_gp_initiator_port_adaptor::tlm2_gp_initiator_port_adaptor(const std::string& name, initiator_port_adaptor::socket_if* sock)
 :  initiator_port_adaptor_impl(name, sock),
    m_address_channel(this, &tlm2_gp_initiator_port_adaptor::captured_channel),
    m_inside_nb_transport_bw(false),
    m_pending_fw_state(false)
{
  // override default attribute values
  m_rd_data_accept_cycles = 0;
  m_wr_rsp_accept_cycles = 0;

  // Just re-use the callback states
  m_eventId2ProtoState[RD_ADDR_START]       = RD_ADDR_START;
  m_eventId2ProtoState[RD_ADDR_END]         = RD_ADDR_END;
  m_eventId2ProtoState[RD_DATA_LAST_START]  = RD_DATA_LAST_START;
  m_eventId2ProtoState[RD_DATA_LAST_END]    = RD_DATA_LAST_END;
  m_eventId2ProtoState[WR_ADDR_START]       = WR_ADDR_START;
  m_eventId2ProtoState[WR_ADDR_END]         = WR_ADDR_END;
  m_eventId2ProtoState[WR_RSP_START]        = WR_RSP_START;
  m_eventId2ProtoState[WR_RSP_END]          = WR_RSP_END;
}

tlm::tlm_phase_enum
tlm2_gp_initiator_port_adaptor::event_id_to_phase(scml2::callback_event_enum event_id)
{
  switch (event_id)
  {
    case RD_ADDR_START:
    case WR_ADDR_START:
      return tlm::BEGIN_REQ;

    case RD_ADDR_END:
    case WR_ADDR_END:
      return tlm::END_REQ;

    case RD_DATA_LAST_START:
    case WR_RSP_START:
      return tlm::BEGIN_RESP;

    case RD_DATA_LAST_END:
    case WR_RSP_END:
      return tlm::END_RESP;

    default:
      return tlm::UNINITIALIZED_PHASE;
  }
}

scml2::callback_event_enum
tlm2_gp_initiator_port_adaptor::phase_to_event_id(tlm::tlm_generic_payload& trans, tlm::tlm_phase& phase)
{
  switch (phase)
  {
    case tlm::BEGIN_REQ:  return trans.is_read() ? scml2::RD_ADDR_START : scml2::WR_ADDR_START;
    case tlm::END_REQ:    return trans.is_read() ? scml2::RD_ADDR_END : scml2::WR_ADDR_END;
    case tlm::BEGIN_RESP: return trans.is_read() ? scml2::RD_DATA_LAST_START : scml2::WR_RSP_START;
    case tlm::END_RESP:   return trans.is_read() ? scml2::RD_DATA_LAST_END : scml2::WR_RSP_END;
    default:
      return scml2::CBK_EVENT_NONE;
  }
}

std::string
tlm2_gp_initiator_port_adaptor::state_name(unsigned int protocol_state) const
{
  switch ((scml2::callback_event_enum)protocol_state)
  {
    case RD_ADDR_START:
    case WR_ADDR_START:
      return "BEGIN_REQ";

    case RD_ADDR_END:
    case WR_ADDR_END:
      return "END_REQ";

    case RD_DATA_LAST_START:
    case WR_RSP_START:
      return "BEGIN_RESP";

    case RD_DATA_LAST_END:
    case WR_RSP_END:
      return "END_RESP";

    default:
      return port_adaptor_impl::state_name(protocol_state);
  }
}

void
tlm2_gp_initiator_port_adaptor::handle_clock_parameter_change_request(scml_clock_parameter_change_control_if* clk_control_if)
{
  initiator_port_adaptor_impl::handle_clock_parameter_change_request(clk_control_if);

  if (m_clk_period_change_pending) {
    // lock address channel so no more transactions are issued while clock change is pending
    m_address_channel.lock();
  }
}

void
tlm2_gp_initiator_port_adaptor::handle_clock_parameters_updated(scml_clock_if* clk)
{
  initiator_port_adaptor_impl::handle_clock_parameters_updated(clk);

  if (clk->running()) {
    // unlock address channel now that clock period change has completed
    if (m_address_channel.is_locked())
      m_address_channel.unlock(SC_ZERO_TIME);
  }
  else {
    // lock address channel while clock is stopped
    m_address_channel.lock();
  }
}

bool
tlm2_gp_initiator_port_adaptor::send_transaction(tlm::tlm_generic_payload& trans, sc_time& t)
{
  PORT_ADAPTOR_TRACE((&trans), t, (trans.is_read() ? "READ_CMD" : "WRITE_CMD"));

  trans.acquire();

  tlm::tlm_phase phase = tlm::BEGIN_REQ;
  m_payloads[&trans].state = phase_to_event_id(trans, phase);
  m_address_channel.request(trans, t, !m_inside_nb_transport_bw);

  return true;
}

/** API invoked from the user to advance the protocol state */
bool
tlm2_gp_initiator_port_adaptor::update_transaction(tlm::tlm_generic_payload& trans, sc_time& t, scml2::callback_event_enum event_id)
{
  // verify that user is attempting a valid state transition
  scml2::callback_event_enum current_state = m_payloads[&trans].state;
  bool state_ok = false;

  switch (current_state) {
    case scml2::RD_DATA_LAST_START: state_ok = (event_id == scml2::RD_DATA_LAST_END); break;
    case scml2::WR_RSP_START:       state_ok = (event_id == scml2::WR_RSP_END); break;
    default:
      break;
  }
  if (!state_ok) {
    PORT_ADAPTOR_TXN_ERROR((&trans), t, "update_transaction invoked with invalid event: "
      << event_name(event_id) << ", current state is " << event_name(current_state));
    return false;
  }

  // set the new state and advance the protocol state machine
  m_payloads[&trans].state = event_id;
  return update_transaction(trans, t);
}

bool
tlm2_gp_initiator_port_adaptor::update_transaction(tlm::tlm_generic_payload& trans, sc_time& t)
{
  PORT_ADAPTOR_TRACE((&trans), t, event_name(m_payloads[&trans].state));

  if (m_inside_nb_transport_bw) {
    // wait to process this state until we unwind back to nb_transport_bw
    if (m_pending_fw_state)
    {
      PORT_ADAPTOR_TXN_ERROR((&trans), t, "update_transaction has been invoked but the previous state has not yet been processed.");
      return false;
    }
    m_pending_fw_state = true;
    m_pending_fw_state_time = t;
  }
  else if (!m_payloads[&trans].early_complete) {
    tlm::tlm_phase phase = event_id_to_phase(m_payloads[&trans].state);
    process_fw_states(trans, phase, t);
  }

  return true;
}

void
tlm2_gp_initiator_port_adaptor::captured_channel(tlm::tlm_generic_payload& trans, sc_time& t)
{
  tlm::tlm_phase phase = event_id_to_phase(m_payloads[&trans].state);
  process_fw_states(trans, phase, t);
}

/* Backward response call from the target */
tlm::tlm_sync_enum
tlm2_gp_initiator_port_adaptor::nb_transport_bw(tlm::tlm_generic_payload& trans, tlm::tlm_phase& phase, sc_time& t)
{
  scml2::callback_event_enum event_id = phase_to_event_id(trans, phase);

  PORT_ADAPTOR_TRACE((&trans), t, event_name(event_id));

  // ignore unrecognised phases
  if (event_id == scml2::CBK_EVENT_NONE) {
    return tlm::TLM_ACCEPTED;
  }

  m_inside_nb_transport_bw = true;
  m_pending_fw_state = false;

  tlm::tlm_sync_enum return_status = process_bw_states(trans, phase, t);

  if (m_pending_fw_state) {
    m_pending_fw_state = false;
    phase = event_id_to_phase(m_payloads[&trans].state);
    t = m_pending_fw_state_time;
    return_status = tlm::TLM_UPDATED;
  }

  if (return_status != tlm::TLM_ACCEPTED) {
    invoke_fwd_timing_callback(m_payloads[&trans].state, trans, t);

    if (phase == tlm::END_RESP) {
      return_status = tlm::TLM_COMPLETED;

      // transaction is complete
      m_payloads.erase(&trans);
      m_address_channel.release(t + m_clk_period);   // channel can be captured again 1 clock cycle later
      on_txn_complete(trans, t + m_clk_period);
    }
  }

  m_inside_nb_transport_bw = false;
  return return_status;
}

tlm::tlm_sync_enum
tlm2_gp_initiator_port_adaptor::process_bw_states(tlm::tlm_generic_payload& trans, tlm::tlm_phase& phase, sc_time& t)
{
  PORT_ADAPTOR_TRACE((&trans), t, event_name(phase_to_event_id(trans, phase)));

  scml2::callback_event_enum current_state = m_payloads[&trans].state;

  // check for skipped ENDREQ phase
  if ((phase == tlm::BEGIN_RESP) &&
      ((current_state == RD_ADDR_START) || (current_state == WR_ADDR_START)))
  {
    tlm::tlm_phase skipped_phase = tlm::END_REQ;
    process_bw_states(trans, skipped_phase, t);
  }

  scml2::callback_event_enum event_id = phase_to_event_id(trans, phase);
  m_payloads[&trans].state = event_id;

  // invoke the callback if associated with this phase, return status indicates
  // whether we advance the phase ourselves or wait for owner to invoke
  // update_transaction
  tlm::tlm_sync_enum return_status = invoke_timing_callback(event_id, trans, t);
  if (return_status != tlm::TLM_UPDATED) {
    return return_status;
  }

  // advance protocol state
  switch (event_id) {
    case scml2::RD_ADDR_END:
    case scml2::WR_ADDR_END:
      return tlm::TLM_ACCEPTED;

    case scml2::RD_DATA_LAST_START:
      t += m_clk_period * m_rd_data_accept_cycles;
      event_id = RD_DATA_LAST_END;
      break;

    case scml2::WR_RSP_START:
      t += m_clk_period * m_wr_rsp_accept_cycles;
      event_id = WR_RSP_END;
      break;

    default:
      PORT_ADAPTOR_TXN_ERROR((&trans), t, "Received invalid phase: " << phase);
      return tlm::TLM_ACCEPTED;
  }

  m_payloads[&trans].state = event_id;
  phase = event_id_to_phase(event_id);

  return tlm::TLM_UPDATED;
}

void
tlm2_gp_initiator_port_adaptor::process_fw_states(tlm::tlm_generic_payload& trans, tlm::tlm_phase& phase, sc_time& t)
{
  PORT_ADAPTOR_TRACE((&trans), t, event_name(phase_to_event_id(trans, phase)));

  scml2::callback_event_enum event_id = phase_to_event_id(trans, phase);
  m_payloads[&trans].state = event_id;

  tlm::tlm_sync_enum status;
  do {
    invoke_fwd_timing_callback((unsigned int)event_id, trans, t);
    status = mSocket->nb_transport_fw(trans, phase, t);
    if (status == tlm::TLM_COMPLETED) {
      // handle skipped phases
      if ((m_payloads[&trans].state != RD_DATA_LAST_END) && (m_payloads[&trans].state != WR_RSP_END)) {
        status = tlm::TLM_UPDATED;
        phase = tlm::BEGIN_RESP;
        m_payloads[&trans].early_complete = true;
      }
    }
    if (status == tlm::TLM_UPDATED)
      status = process_bw_states(trans, phase, t);
  } while (status == tlm::TLM_UPDATED);

  if ((status == tlm::TLM_COMPLETED) ||
      (m_payloads[&trans].state == RD_DATA_LAST_END) ||
      (m_payloads[&trans].state == WR_RSP_END)) {
    // transaction is complete
    m_payloads.erase(&trans);
    m_address_channel.release(t + m_clk_period);   // channel can be captured again 1 clock cycle later
    on_txn_complete(trans, t + m_clk_period);
  }
}

} // namespace scml2

