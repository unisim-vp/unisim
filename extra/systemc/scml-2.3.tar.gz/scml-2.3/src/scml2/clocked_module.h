// -*- C++ -*-
/*****************************************************************************
 *                   Copyright (C) 2009-2011 Synopsys, Inc.                  *
 *       This software and the associated documentation are confidential     *
 *                  and proprietary to Synopsys, Inc.                        *
 *        Your use or disclosure of this software is subject                 *
 *      to the terms and conditions of a written license agreement           *
 *           between you, or your company, and Synopsys, Inc.                *
 *                                                                           *
 *****************************************************************************/
#ifndef SCML2_CLOCK_IF_H
#define SCML2_CLOCK_IF_H

#include <scml_clock/clocked_module.h>
#include <scml_clock/scml_clock.h>

#endif
// {{{ Emacs local variables

// Local variables:
// folded-file: t
// c-file-style: "coware"
// End:

// }}}
