/*****************************************************************************
 *                   Copyright (C) 2014 Synopsys, Inc.                       *
 *       This software and the associated documentation are confidential     *
 *                  and proprietary to Synopsys, Inc.                        *
 *        Your use or disclosure of this software is subject                 *
 *      to the terms and conditions of a written license agreement           *
 *           between you, or your company, and Synopsys, Inc.                *
 *                                                                           *
 *****************************************************************************/
#ifndef __TLM2_GP_INITIATOR_PORT_ADAPTOR_H__
#define __TLM2_GP_INITIATOR_PORT_ADAPTOR_H__

#include <tlm.h>
#include <scml2/initiator_port_adaptor_impl.h>

namespace scml2
{

class tlm2_gp_initiator_port_adaptor : public initiator_port_adaptor_impl
{
public:
  tlm2_gp_initiator_port_adaptor(const std::string& name, initiator_port_adaptor::socket_if* sock);

  /* Port adaptor protocol details */
  virtual std::string get_protocol() const { return "TLM2_GP"; }
  virtual bool has_data_phase() const { return false; }
  virtual bool has_wr_rsp() const { return true; }

  virtual bool is_idle() const { return !m_address_channel.is_busy(); }

  /* FT initiator state machine interface */
  virtual bool send_transaction(tlm::tlm_generic_payload& trans, sc_time& t);
  virtual bool update_transaction(tlm::tlm_generic_payload& trans, sc_time& t);
  virtual bool update_transaction(tlm::tlm_generic_payload& trans, sc_time& t, scml2::callback_event_enum event_id);
  virtual tlm::tlm_sync_enum nb_transport_bw(tlm::tlm_generic_payload& trans, tlm::tlm_phase& phase, sc_time& t);

protected:
  virtual std::string state_name(unsigned int protocol_state) const;

  virtual void handle_clock_parameter_change_request(scml_clock_parameter_change_control_if* clk_control_if);
  virtual void handle_clock_parameters_updated(scml_clock_if* clk);

private:
  void captured_channel(tlm::tlm_generic_payload& trans, sc_time& t);

  tlm::tlm_phase_enum event_id_to_phase(scml2::callback_event_enum event_id);
  scml2::callback_event_enum phase_to_event_id(tlm::tlm_generic_payload& trans, tlm::tlm_phase& phase);
  tlm::tlm_sync_enum process_bw_states(tlm::tlm_generic_payload& trans, tlm::tlm_phase& phase, sc_time& t);
  void process_fw_states(tlm::tlm_generic_payload& trans, tlm::tlm_phase& phase, sc_time& t);

private:
  struct payload_info
  {
    bool early_complete;
    scml2::callback_event_enum state;
    payload_info() : early_complete(false), state(scml2::MAX_CBK_EVENT_ID_E) { }
  };

  std::map<tlm::tlm_generic_payload*, payload_info> m_payloads;
  scml2::ft_channel<tlm2_gp_initiator_port_adaptor>   m_address_channel;

  bool m_inside_nb_transport_bw;
  bool m_pending_fw_state;
  sc_time m_pending_fw_state_time;
};

} // namespace scml2

#endif  // __TLM2_GP_INITIATOR_PORT_ADAPTOR_H__
