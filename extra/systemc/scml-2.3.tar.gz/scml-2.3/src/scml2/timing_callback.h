/*****************************************************************************
 *                   Copyright (C) 20014 Synopsys, Inc.                      *
 *       This software and the associated documentation are confidential     *
 *                  and proprietary to Synopsys, Inc.                        *
 *        Your use or disclosure of this software is subject                 *
 *      to the terms and conditions of a written license agreement           *
 *           between you, or your company, and Synopsys, Inc.                *
 *                                                                           *
 *****************************************************************************/
#ifndef SCML2_TIMING_CALLBACK_H
#define SCML2_TIMING_CALLBACK_H

namespace tlm {
  class tlm_generic_payload;
}

namespace sc_core {
  class sc_time;
}

namespace scml2
{

class timing_callback_base
{
public:
  virtual tlm::tlm_sync_enum execute(tlm::tlm_generic_payload& trans, sc_time& t) = 0;
};

template <typename C>
class timing_callback0 : public timing_callback_base
{
public:
  typedef tlm::tlm_sync_enum (C::*CallbackType)(tlm::tlm_generic_payload&, sc_core::sc_time&);

  timing_callback0(C* c, CallbackType cb) : mClass(c), mCallback(cb) { }
  tlm::tlm_sync_enum execute(tlm::tlm_generic_payload& trans, sc_core::sc_time& t) { return (*mClass.*mCallback)(trans, t); }

private:
  C* mClass;
  CallbackType mCallback;
};

template <typename C, typename A>
class timing_callback1 : public timing_callback_base
{
public:
  typedef tlm::tlm_sync_enum (C::*CallbackType)(tlm::tlm_generic_payload&, sc_core::sc_time&, A);

  timing_callback1(C* c, CallbackType cb, A a) : mClass(c), mCallback(cb), mArg1(a) { }
  tlm::tlm_sync_enum execute(tlm::tlm_generic_payload& trans, sc_core::sc_time& t) { return (*mClass.*mCallback)(trans, t, mArg1); }

private:
  C* mClass;
  CallbackType mCallback;
  A mArg1;
};

// provide consistent interface to create timing callbacks with variable number of arguments
template <typename C>
timing_callback_base* create_timing_callback(C* c, typename timing_callback0<C>::CallbackType cb)
{
  return new timing_callback0<C>(c, cb);
}

template <typename C, typename A>
timing_callback_base* create_timing_callback(C* c, typename timing_callback1<C, A>::CallbackType cb, A a)
{
  return new timing_callback1<C, A>(c, cb, a);
}

}

#endif
