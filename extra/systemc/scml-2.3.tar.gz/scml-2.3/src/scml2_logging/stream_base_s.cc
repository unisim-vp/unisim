/*****************************************************************************
 *                   Copyright (C) 2014 Synopsys, Inc.                       *
 *       This software and the associated documentation are confidential     *
 *                  and proprietary to Synopsys, Inc.                        *
 *        Your use or disclosure of this software is subject                 *
 *      to the terms and conditions of a written license agreement           *
 *           between you, or your company, and Synopsys, Inc.                *
 *                                                                           *
 *****************************************************************************/
#include <scml2_logging/stream_base_s.h>

namespace scml2 { namespace logging {

#ifdef _WIN32
# pragma warning(push)
# pragma warning(disable: 4355)
#endif

stream_base_s::
stream_base_s(const std::string& name, const severity& severity)
: stream_base(name, severity)
, mStreamBuf(*this)
{
}

#ifdef _WIN32
# pragma warning(pop)
#endif

stream_base_s::
~stream_base_s()
{
}

} }
