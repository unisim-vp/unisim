// -*- C++ -*-
/*****************************************************************************
 *                   Copyright (C) 2009-2013 Synopsys, Inc.                  *
 *       This software and the associated documentation are confidential     *
 *                  and proprietary to Synopsys, Inc.                        *
 *        Your use or disclosure of this software is subject                 *
 *      to the terms and conditions of a written license agreement           *
 *           between you, or your company, and Synopsys, Inc.                *
 *                                                                           *
 *****************************************************************************/
#include "master_configurator.h"
#include "engine.h"
#include <sysc/kernel/sc_simcontext.h>

n_scml_clock::master_configurator::master_configurator(
   engine* e, const sc_core::sc_time& period, const sc_core::sc_time& offset, double duty_cycle, bool posedge_first
) : configurator(e, true), mEnabled(true), mPeriod(period), mOffset(offset), mDutyCycle(duty_cycle), mPosedgeFirst(posedge_first)
{
   assert(!sc_core::sc_is_running());
   handle_parameters_changed();
}

void n_scml_clock::master_configurator::set_period(const sc_core::sc_time& period) {
   mPeriod = period;
   if (sc_core::sc_is_running()) {
      mOffset = sc_core::sc_time_stamp();
      if (mEnabled) {
	 mOffset += mPeriod;
      }
   }
   handle_parameters_changed();
}

void n_scml_clock::master_configurator::set_offset(const sc_core::sc_time& offset) {
   if (sc_core::sc_is_running()) {
      std::cerr << "Error in scml_clock \"" << mEngine->name() << "\": set_offset() called after construction!" << std::endl;
      abort();
   }
   mOffset = offset;
   handle_parameters_changed();
}

void n_scml_clock::master_configurator::set_duty_cycle(double duty_cycle) {
   mDutyCycle = duty_cycle;
   if (sc_core::sc_is_running()) {
      mOffset = sc_core::sc_time_stamp();
      if (mEnabled) {
	 mOffset += mPeriod;
      }
   }
   handle_parameters_changed();
}

void n_scml_clock::master_configurator::set_posedge_first(bool posedge_first) {
   if (sc_core::sc_is_running()) {
      std::cerr << "Error in scml_clock \"" << mEngine->name() << "\": set_posedge_first() called after construction!" << std::endl;
      abort();
   }
   mPosedgeFirst = posedge_first;
   handle_parameters_changed();
}

void n_scml_clock::master_configurator::set_period_multiplier(double) {
   std::cerr << "Error in scml_clock \"" << mEngine->name() << "\": calling set_period_multiplier() is invalid for a master clock!" << std::endl;
   abort();
}

void n_scml_clock::master_configurator::set_enabled(bool enabled) {
   mEnabled = enabled;
   if (sc_core::sc_is_running()) {
      mOffset = sc_core::sc_time_stamp();
      if (mEnabled) {
	 mOffset += mPeriod;
      }
   }
   handle_parameters_changed();
}

void n_scml_clock::master_configurator::handle_parameters_changed() {
   if (mPeriod == sc_core::SC_ZERO_TIME) {
      std::cerr << "Error in scml_clock \"" << mEngine->name() << "\": period is zero! Increase the period" << std::endl;
      abort();
   }
   if (mDutyCycle<=0.0 || 1.0<=mDutyCycle) {
      std::cerr << "Warning in scml_clock \"" << mEngine->name() << "\": duty cylce " << mDutyCycle
		<< " is out of range (0..1). Changing to 0.5" << std::endl;
      mDutyCycle = 0.5;
   }
   if (!sc_core::sc_is_running()) {
      mEngineEnabled = mEnabled;
      mEngine->init(mPeriod, mOffset, mDutyCycle, mPosedgeFirst, mEnabled);
   } else {
      mEngine->trigger_parameter_change();
   }
   notify_childen();
}

void n_scml_clock::master_configurator::get_next_parameters(bool& running, sc_core::sc_time& period, double& duty_cycle, sc_core::sc_time& offset) {
   running = mEnabled;
   period = mPeriod;
   duty_cycle = mDutyCycle;
   offset = mOffset;
   mEngineEnabled = mEnabled;
}

sc_core::sc_time n_scml_clock::master_configurator::get_next_period_start_time() const {
   assert(mEnabled);

   sc_core::sc_time now = sc_core::sc_time_stamp();
   
   if (now < mOffset) {
      return mOffset;
   }

   return now - sc_core::sc_time((now-mOffset).value()%mPeriod.value(), false) + mPeriod;
}

// {{{ Emacs local variables

// Local variables:
// folded-file: t
// c-file-style: "coware"
// End:

// }}}
