// -*- C++ -*-
/*****************************************************************************
 *                   Copyright (C) 2009-2013 Synopsys, Inc.                  *
 *       This software and the associated documentation are confidential     *
 *                  and proprietary to Synopsys, Inc.                        *
 *        Your use or disclosure of this software is subject                 *
 *      to the terms and conditions of a written license agreement           *
 *           between you, or your company, and Synopsys, Inc.                *
 *                                                                           *
 *****************************************************************************/

#include "gate.h"

scml_clock_gate::scml_clock_gate(sc_core::sc_module_name n) : sc_module(n), mClock(n, clk, 1, 0) {
   SC_METHOD(handle_enable);
   sensitive << en;
   mClock.disable();
}

void scml_clock_gate::enable() {
   std::cerr << "Error in scml_clock_gate \"" << name() << "\": scml_clock_gate needs to be disabled through the en port";
   abort();
}

void scml_clock_gate::disable() {
   std::cerr << "Error in scml_clock_gate \"" << name() << "\": scml_clock_gate needs to be enabled through the en port";
   abort();
}

void scml_clock_gate::set_duty_cycle(double) {
   std::cerr << "Error in scml_clock_gate \"" << name() << "\": set_duty_cycle not supporetd for scml_clock_gate" << std::endl;
   abort();
}

void scml_clock_gate::set_start_time(const sc_core::sc_time&) {
   std::cerr << "Error in scml_clock_gate \"" << name() << "\": set_start_time not supported for scml_clock_gate" << std::endl;
   abort();
}

void scml_clock_gate::set_period(const sc_core::sc_time&) {
   std::cerr << "Error in scml_clock_gate \"" << name() << "\": set_period not supported for scml_clock_gate" << std::endl;
   abort();
}

void scml_clock_gate::set_posedge_first(bool) {
   std::cerr << "Error in scml_clock_gate \"" << name() << "\": set_posedge_first not supported for scml_clock_gate" << std::endl;
   abort();
}

void scml_clock_gate::set_period_multiplier(double) {
   std::cerr << "Error in scml_clock_gate \"" << name() << "\": set_period_multiplier not supported for scml_clock_gate" << std::endl;
   abort();
}

void scml_clock_gate::handle_enable() {
   if (en.read()) {
      mClock.enable();
   } else {
      mClock.disable();
   }
}


// {{{ Emacs local variables

// Local variables:
// folded-file: t
// c-file-style: "coware"
// End:

// }}}
