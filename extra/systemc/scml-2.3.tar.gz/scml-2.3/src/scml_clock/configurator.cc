// -*- C++ -*-
/*****************************************************************************
 *                   Copyright (C) 2009-2013 Synopsys, Inc.                  *
 *       This software and the associated documentation are confidential     *
 *                  and proprietary to Synopsys, Inc.                        *
 *        Your use or disclosure of this software is subject                 *
 *      to the terms and conditions of a written license agreement           *
 *           between you, or your company, and Synopsys, Inc.                *
 *                                                                           *
 *****************************************************************************/
#include "configurator.h"
#include <sysc/kernel/sc_simcontext.h>

n_scml_clock::configurator::~configurator() {
   // notify children
   tChildren copy = mChildren;
   for (size_t i=0; i<mChildren.size(); ++i) {
      mChildren[i]->handle_parent_deleted(this);
   }
}

void n_scml_clock::configurator::register_child(child* c) {
   mChildren.push_back(c);
}

void n_scml_clock::configurator::unregister_child(child* c) {
   for (tChildren::iterator i=mChildren.begin(); i!=mChildren.end(); ++i) {
      if (*i == c) {
	 mChildren.erase(i);
	 break;
      }
   }
}

void n_scml_clock::configurator::notify_childen() {
   tChildren copy = mChildren;
   for (size_t i=0; i<mChildren.size(); ++i) {
      mChildren[i]->handle_parent_parameters_changed(this);
   }
}

// {{{ Emacs local variables

// Local variables:
// folded-file: t
// c-file-style: "coware"
// End:

// }}}
