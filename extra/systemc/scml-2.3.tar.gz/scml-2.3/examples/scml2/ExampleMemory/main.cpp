// Copyright (c) 2009 CoWare, Inc.
// All rights reserved worldwide.

#include <ExampleMemory.h>
#include <ExampleMemory_new.h>
#include <MemoryCheck.h>
#include <systemc>

int sc_main(int argc, char* argv[])
{
  MemoryCheck memoryCheck("memoryCheck");
  MemoryCheck memoryCheck_1("memoryCheck_1");
  ExampleMemory exampleMemory("exampleMemory");
  //Memory using new port adaptor
  ExampleMem exampleMem("exampleMem");

  memoryCheck.socket(exampleMemory.socket);
  memoryCheck_1.socket(exampleMem.socket);

  sc_core::sc_start();

  return 0;
}
