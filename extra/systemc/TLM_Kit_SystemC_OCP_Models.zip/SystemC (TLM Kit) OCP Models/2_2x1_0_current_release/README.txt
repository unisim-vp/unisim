To install this package and to run the examples do the following:

0. Notes:
0.1  'make' means 'gmake'. If that is not the default (like on SunOS) edit the
     Makefiles to explicitly call 'gmake'
0.2  The installation needs the tool named 'tail' this is widely supported by
     Unix distributions and derivates (like Linux, MacOS, BSD...). However,
     there are some variants of this tool available, and we need the one that
     supports the option '-n'. This is the default on linux and macos, but not
     on SunOS. If it is not the default, edit the Makefile and cp_legacy script 
     to point to a correct version (e.g. on SunOS a working version 
     is '/usr/xpg4/bin/tail').
0.3  The Makefiles for the examples assume existence of bash in /bin/bash. If that
     is not the case, edit Makefile.generic in the examples directory accordingly.
     (Note: You may simply remove setting the SHELL variable, as 'bash' is only
     needed for 'make check')

1. Install OCPIP

1.1
untar the tgz files (socket, monitors). Note that the tar files directly contain the
include, src, etc. directories, so it is strongly adviced to create a (temporary) directory
within which the tar files should be extracted. Both (sockets and monitors) can be extracted
within the same temporary directory, as long as their release versions match.

1.2 go into the directory in which you untared the tar socket file.

1.3 change the Makefile so it matches your system (the Makefile contains explanations)
Note: the kit will be placed directly in the directory you specified. If it does not exist it will be created.

1.4 type:
make install

1.5 type:
make install_examples

2. build and run examples
Now you should have an examples directory inside the target directory that you have chosen.

Go into one of the example directories (e.g. ocp_tl1_simple) and type make.
Then type 'make run' to execute an example.


Some of the examples do not make much sense without a monitor attached, so you can do the optional steps 3 and 4.

3. make sure you have SCV

4. 'install' monitor package

4.1 go into the directory in which you untared the monitor tar file

4.2 go into the subdirectory mon

4.3 modify the Makefile so that it matches your system (there are explanations in the Makefile)

4.4 type:
make install

Now you can rebuild all examples and they will use monitors.

