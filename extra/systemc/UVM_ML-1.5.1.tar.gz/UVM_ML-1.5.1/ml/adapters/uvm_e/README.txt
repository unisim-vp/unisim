UVM-e within Specman and IES release is fully compatible with UVM-ML. 
There is no need for a UVM-e framework within the UVM-ML installation. 

To use e code in a UVM-ML environment, the appropriate Incisive IES or Specman 
release must be used. 

For more information and specific version recommendations, see 
$UVM_ML_HOME/ml/README_INSTALLATION.txt or the UVM-ML reference manual.
